package com.in2it.irecruit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IRecruitApplicationTests {

	@Test
	void contextLoads() {
	}

}
