package com.in2it.irecruit.global.exceptionhandler;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.in2it.irecruit.exception.UnexpectedInternalError;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("timestamp", new Date());
		body.put("status", status.value());

		// Get all errors
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getDefaultMessage())
				.collect(Collectors.toList());

		body.put("errors", errors);

		return new ResponseEntity<>(body, headers, status);
	}

	@ExceptionHandler({ ConstraintViolationException.class, UnexpectedInternalError.class, NumberFormatException.class})
	protected ResponseEntity<Object> handleAPICustomExceptions(Exception ex, WebRequest request) {

		if (ex instanceof ConstraintViolationException) {
			HttpStatus status = HttpStatus.BAD_REQUEST;
			return handleConstraintViolationException(ex, status);
		}
		if (ex instanceof UnexpectedInternalError) {
			HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
			return handleUnexpectedInternalErrorException(ex, status);
		}
		if(ex instanceof NumberFormatException) {
			HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
			return handleNumberFormatException(ex, status);
		}
		return null;
	}

	private ResponseEntity<Object> handleNumberFormatException(Exception ex, HttpStatus status) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", ((NumberFormatException) ex).getMessage());
		body.put("status", status);
		return new ResponseEntity<>(body, status);
	}

	private ResponseEntity<Object> handleUnexpectedInternalErrorException(Exception ex, HttpStatus status) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", ((UnexpectedInternalError) ex).getMessage());
		body.put("status", status);
		return new ResponseEntity<>(body, status);
	}

	private ResponseEntity<Object> handleConstraintViolationException(Exception ex, HttpStatus status) {
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("message", ((ConstraintViolationException) ex).getMessage());
		body.put("status", status);
		return new ResponseEntity<>(body, status);
	}
}
