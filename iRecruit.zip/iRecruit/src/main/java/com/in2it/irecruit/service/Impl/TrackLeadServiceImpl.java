package com.in2it.irecruit.service.Impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.TrackLead;
import com.in2it.irecruit.repository.TrackLeadRepository;
import com.in2it.irecruit.service.ERFService;
import com.in2it.irecruit.service.TrackLeadService;

@Service
public class TrackLeadServiceImpl implements TrackLeadService {

	@Autowired
	private TrackLeadRepository trackLeadRepo;

	@Autowired
	ERFService erfService;

	@Override
	public List<TrackLead> saveTrackLead(List<TrackLead> trackLeadData) throws UnexpectedInternalError {

		isBudgetOrPositionExceeded(trackLeadData);

		for (TrackLead trackLead : trackLeadData) {
			trackLead.setAssignDate(LocalDate.now());
		}
		
		try {
			return trackLeadRepo.saveAll(trackLeadData);
		}catch (DataIntegrityViolationException e) {
			throw new UnexpectedInternalError("Multiple assignments not allowed for a single track-lead.");
		}
	}
	
	@Override
	public List<TrackLead> getTrackleadsForErf(long erfId) {
		ERF erf = new ERF();
		erf.setErfId(erfId);
		return trackLeadRepo.findByErf(erf);
	}

	private boolean isBudgetOrPositionExceeded(List<TrackLead> trackleads) throws UnexpectedInternalError {

		if (trackleads != null && !trackleads.isEmpty()) {

			ERF erf = erfService.viewERFById(trackleads.get(0).getErf().getErfId());
			List<TrackLead> existingTrackleads = trackLeadRepo.findByErf(erf);

			long existingTrackleadBudget = 0;
			long existingTrackleadPosition = 0;

			for (TrackLead trackLead : existingTrackleads) {
				existingTrackleadBudget += trackLead.getBudget();
				existingTrackleadPosition += trackLead.getPosition();
			}

			long newTrackleadBudget = 0;
			long newTrackleadPosition = 0;

			for (TrackLead trackLead : trackleads) {
				newTrackleadBudget += trackLead.getBudget();
				newTrackleadPosition += trackLead.getPosition();
			}

			if ((existingTrackleadBudget + newTrackleadBudget) > erf.getMaxBudget()) {
				throw new UnexpectedInternalError("Cannot add Tracklead(s). Budget exceeded.");
			} else if ((existingTrackleadPosition + newTrackleadPosition) > erf.getTotalPosition()) {
				throw new UnexpectedInternalError("Cannot add Tracklead(s). Positions exceeded.");
			}
		}

		return false;
	}

	@Override
	public TrackLead findByErfAndUser(ERF erf, AppUser createdBy) {
		return trackLeadRepo.findByErfAndUser(erf, createdBy);
	}
}
