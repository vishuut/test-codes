package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.TrackLead;

@Repository
public interface TrackLeadRepository extends JpaRepository<TrackLead, Long> {
	
	List<TrackLead> findByErf(ERF erf);

	TrackLead findByErfAndUser(ERF erf, AppUser createdBy);

}
