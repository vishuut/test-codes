package com.in2it.irecruit.constant;

public class UserSQLConstant {
	
	public static final String DISTINCT_USER_DETARTMENTS = "SELECT DISTINCT u.department FROM user u WHERE u.department IS NOT NULL"; 

}
