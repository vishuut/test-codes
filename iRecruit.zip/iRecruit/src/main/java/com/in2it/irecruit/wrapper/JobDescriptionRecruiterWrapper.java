package com.in2it.irecruit.wrapper;

import java.util.List;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.JobDescription;

public class JobDescriptionRecruiterWrapper {

	private JobDescription jobDescription;

	private List<AppUser> user;

	public JobDescriptionRecruiterWrapper() {
		super();
	}

	public JobDescriptionRecruiterWrapper(JobDescription jobDescription, List<AppUser> user) {
		super();
		this.jobDescription = jobDescription;
		this.user = user;
	}

	public JobDescription getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(JobDescription jobDescription) {
		this.jobDescription = jobDescription;
	}

	public List<AppUser> getUser() {
		return user;
	}

	public void setUser(List<AppUser> user) {
		this.user = user;
	}
}
