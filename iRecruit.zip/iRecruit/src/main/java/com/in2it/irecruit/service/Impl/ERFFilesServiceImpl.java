package com.in2it.irecruit.service.Impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.in2it.irecruit.service.ERFFilesService;

@Service
public class ERFFilesServiceImpl implements ERFFilesService {

	@Override
	public String saveFileFromMultipartFormData(MultipartFile file, String targetDirPath, String fileName) {
		File fileToSave;
		
		try {
			fileToSave = createTargetFile(file, targetDirPath, fileName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
		
		try (InputStream in = file.getInputStream(); OutputStream out = new FileOutputStream(fileToSave)) {
            FileCopyUtils.copy(in, out);
            return fileToSave.getPath();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
	}

	@Override
	public List<String> saveMultipleFilesFromMultipartFormData(MultipartFile[] files, String targetDirPath) {
		return null;
	}
	
	@Override
	public Resource getFileAsResource(String filePath) {
		Resource fileResource = new FileSystemResource(new File(filePath));
		return fileResource;
	}
	
	private File createTargetFile(MultipartFile file, String targetDir, String fileName) throws IOException
    {
        File uploadPath = Paths.get(targetDir).toFile();
        if(uploadPath.exists() == false) {
            uploadPath.mkdirs();
        }
        return new File(uploadPath.getAbsolutePath(), fileName + "." + FilenameUtils.getExtension(file.getOriginalFilename()));
    }

}
