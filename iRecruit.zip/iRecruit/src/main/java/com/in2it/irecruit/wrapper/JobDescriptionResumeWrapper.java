package com.in2it.irecruit.wrapper;

import java.util.List;

import com.in2it.irecruit.model.JobDescription;
import com.in2it.irecruit.model.ResumeData;

public class JobDescriptionResumeWrapper {
	
	private JobDescription jobDescription;
	
	private List<ResumeData> resumes;

	public JobDescriptionResumeWrapper() {
		super();
	}

	public JobDescriptionResumeWrapper(JobDescription jobDescription, List<ResumeData> resumes) {
		super();
		this.jobDescription = jobDescription;
		this.resumes = resumes;
	}

	public JobDescription getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(JobDescription jobDescription) {
		this.jobDescription = jobDescription;
	}

	public List<ResumeData> getResumes() {
		return resumes;
	}

	public void setResumes(List<ResumeData> resumes) {
		this.resumes = resumes;
	}
}
