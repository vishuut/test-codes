package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.OfficeLocation;

@Repository
public interface OfficeLocationRepository extends JpaRepository<OfficeLocation, Long> {
	
	List<OfficeLocation> findByCountry(Country country);

}
