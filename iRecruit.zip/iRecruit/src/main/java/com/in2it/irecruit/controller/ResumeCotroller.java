package com.in2it.irecruit.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MimeType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.in2it.irecruit.exception.InvalidFileTypeException;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.ResumeData;
import com.in2it.irecruit.service.ResumeDataService;

@RestController
@RequestMapping(value = "/irecruit-api/resume")
public class ResumeCotroller {
	
	@Autowired
	private ResumeDataService resumeDataService;
	
	
	@PostMapping(value = "/save-resume", consumes = { "multipart/form-data" })
	public ResponseEntity<ResumeData> uploadFile(@RequestParam(name = "file") MultipartFile file, HttpServletRequest request) throws InvalidFileTypeException, UnexpectedInternalError {
		return ResponseEntity.ok(resumeDataService.saveResumeData(request, file));
	}
	
	@GetMapping(value = "/download/{resumeId}")
	public ResponseEntity<Resource> downloadResumeFile(@PathVariable(name = "resumeId", required = true) long resumeId) {
		Resource file = resumeDataService.downloadResume(resumeId);
		ResponseEntity<Resource> response = null;
		
		String ext = FilenameUtils.getExtension(file.getFilename());
		
		if(ext.equalsIgnoreCase("pdf")) {
			response = ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(file);
		}else if(ext.equalsIgnoreCase("doc")) {
			response = ResponseEntity.ok().contentType(MediaType.asMediaType(MimeType.valueOf("application/msword"))).body(file);
		}else if(ext.equalsIgnoreCase("docx")) {
			response = ResponseEntity.ok().contentType(MediaType.asMediaType(MimeType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))).body(file);
		}else if(ext.equalsIgnoreCase("txt")) {
			response = ResponseEntity.ok().contentType(MediaType.TEXT_PLAIN).body(file);
		}else {
			response = ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(file);
		}
		
		return response;
	}
	
	
}
