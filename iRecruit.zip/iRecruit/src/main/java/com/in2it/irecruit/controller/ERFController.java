package com.in2it.irecruit.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.service.ERFService;

@RestController
@RequestMapping(value = "/irecruit-api/erf")
@Validated
public class ERFController {

	@Autowired
	private ERFService erfService;

	@PostMapping(value = "/save-erf")
	@PreAuthorize("hasAuthority('ERF_GENERATE')")
	public ResponseEntity<ERF> addNewERF(@Valid @RequestBody ERF erf, Principal userPrincipal) {
		return new ResponseEntity<ERF>(erfService.saveERF(erf, userPrincipal), HttpStatus.OK);
	}

	@GetMapping(value = "/view-erf")
	@PreAuthorize("hasAuthority('ERF_VIEW')")
	public ResponseEntity<List<ERF>> viewERF(Principal userPrincipal) throws UnexpectedInternalError {
		return new ResponseEntity<List<ERF>>(erfService.viewERF(userPrincipal), HttpStatus.OK);
	}

	@GetMapping(value = "/view-erf/{erfId}")
	@PreAuthorize("hasAuthority('ERF_VIEW')")
	public ResponseEntity<ERF> viewERFById(@PathVariable long erfId) throws UnexpectedInternalError {
		return new ResponseEntity<ERF>(erfService.viewERFById(erfId), HttpStatus.OK);
	}
	
}
