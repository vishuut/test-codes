package com.in2it.irecruit.exception;

public class InvalidFileTypeException extends Exception {
	
	private static final long serialVersionUID = -7111726045978188101L;
	
	public InvalidFileTypeException() {
		super("The given file type is not supported.");
	}
	
	public InvalidFileTypeException(String message) {
		super(message);
	}
	
}
