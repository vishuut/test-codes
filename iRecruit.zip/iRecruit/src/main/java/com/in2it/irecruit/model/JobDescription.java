package com.in2it.irecruit.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.in2it.irecruit.util.StringUtil;

@Entity
public class JobDescription {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private long noOfEmployee;
	@OneToOne
	private ERFAddress workLocation;
	@OneToOne
	private ERFAddress sourceLocation;
	private long budget;
	@Column(columnDefinition = "TEXT")
	private String body;
	private String additionalDetail;
	private String domain;
	@Transient
	private List<String> additionalCategory;
	@Column(name = "additionalCategories", columnDefinition = "VARCHAR(1000) default ''")
	@JsonIgnore
	private String concatinatedAdditionalCategory;
	@Column(columnDefinition = "TINYINT")
	private int minExprience;
	@Column(columnDefinition = "TINYINT")
	private int maxExprience;
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonProperty(access = Access.WRITE_ONLY)
	private ERF erf;
	@OneToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private AppUser createdBy;

	public JobDescription() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getNoOfEmployee() {
		return noOfEmployee;
	}

	public void setNoOfEmployee(long noOfEmployee) {
		this.noOfEmployee = noOfEmployee;
	}

	public ERFAddress getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(ERFAddress workLocation) {
		this.workLocation = workLocation;
	}

	public ERFAddress getSourceLocation() {
		return sourceLocation;
	}

	public void setSourceLocation(ERFAddress sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	public long getBudget() {
		return budget;
	}

	public void setBudget(long budget) {
		this.budget = budget;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getAdditionalDetail() {
		return additionalDetail;
	}

	public void setAdditionalDetail(String additionalDetail) {
		this.additionalDetail = additionalDetail;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public List<String> getAdditionalCategory() {
		return additionalCategory;
	}

	public void setAdditionalCategory(List<String> additionalCategory) {
		this.additionalCategory = additionalCategory;
		this.concatinatedAdditionalCategory = StringUtil.toCommaSaperatedString(additionalCategory);
	}

	public String getConcatinatedAdditionalCategory() {
		return concatinatedAdditionalCategory;
	}

	public void setConcatinatedAdditionalCategory(String concatinatedAdditionalCategory) {
		this.concatinatedAdditionalCategory = concatinatedAdditionalCategory;
		this.additionalCategory = StringUtil.toListOfString(concatinatedAdditionalCategory, ",");
	}

	public int getMinExprience() {
		return minExprience;
	}

	public void setMinExprience(int minExprience) {
		this.minExprience = minExprience;
	}

	public int getMaxExprience() {
		return maxExprience;
	}

	public void setMaxExprience(int maxExprience) {
		this.maxExprience = maxExprience;
	}

	public ERF getErf() {
		return erf;
	}

	public void setErf(ERF erf) {
		this.erf = erf;
	}

	public AppUser getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AppUser createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "JobDescription [id=" + id + ", noOfEmployee=" + noOfEmployee + ", workLocation=" + workLocation
				+ ", sourceLocation=" + sourceLocation + ", budget=" + budget + ", body=" + body + ", additionalDetail="
				+ additionalDetail + ", domain=" + domain + ", additionalCategory=" + additionalCategory
				+ ", concatinatedAdditionalCategory=" + concatinatedAdditionalCategory + ", minExprience="
				+ minExprience + ", maxExprience=" + maxExprience + ", erf=" + erf + ", createdBy=" + createdBy + "]";
	}

}
