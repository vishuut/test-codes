package com.in2it.irecruit.repository.customimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;

import com.in2it.irecruit.constant.DataFilterType;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.DataFilter;
import com.in2it.irecruit.model.DataFilterValue;
import com.in2it.irecruit.model.Department;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.OfficeLocation;
import com.in2it.irecruit.model.OrganizationEntity;
import com.in2it.irecruit.model.Project;
import com.in2it.irecruit.model.ResourceAllocation;
import com.in2it.irecruit.repository.CountryRepository;
import com.in2it.irecruit.repository.CustomERFRepository;
import com.in2it.irecruit.repository.DataFilterRepository;
import com.in2it.irecruit.repository.DepartmentRepository;
import com.in2it.irecruit.repository.OfficeLocationRepository;
import com.in2it.irecruit.repository.OrganizationEntityRepository;
import com.in2it.irecruit.repository.ProjectRepository;
import com.in2it.irecruit.repository.ResourceAllocationRepository;

public class CustomERFRepositoryImpl implements CustomERFRepository {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	DataFilterRepository dataFilterRepo;

	@Autowired
	CountryRepository countryRepo;

	@Autowired
	DepartmentRepository departmentRepo;
	
	@Autowired
	OrganizationEntityRepository entityRepo;
	
	@Autowired
	ProjectRepository projectRepo;
	
	@Autowired
	ResourceAllocationRepository resourceAllocationRepo;
	
	@Autowired
	private OfficeLocationRepository officeLocationRepo;

	@Override
	public List<ERF> findERFByFiltersCriteria(AppUser user) throws UnexpectedInternalError {

		List<DataFilter> filters = dataFilterRepo.findByUserAndActive(user, true);

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<ERF> qr = cb.createQuery(ERF.class);
		Root<ERF> erf = qr.from(ERF.class);

		qr.select(erf);

		if (filters != null && !filters.isEmpty()) {
			
			List<Predicate> predicates = new ArrayList<Predicate>();

			for (DataFilter filter : filters) {

				List<DataFilterValue> filterValues = filter.getDataFilterValues();
				

				if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.NO_FILTER) {

					return entityManager.createQuery(qr).getResultList();
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_1) {

//					List<Long> countryIds = new ArrayList<>();
//
//					for (DataFilterValue filterValue : filterValues) {
//						countryIds.add(filterValue.getFilterValueId());
//					}
//
//					List<Country> countries = countryRepo.findAllById(countryIds);
//
//					In<Country> countryInClause = cb.in(erf.get("workCountry"));
//
//					for (Country country : countries) {
//						countryInClause.value(country);
//					}
//					
//					predicates.add(countryInClause);
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_2) {

					List<Long> departmentIds = new ArrayList<>();

					for (DataFilterValue filterValue : filterValues) {
						departmentIds.add(filterValue.getFilterValueId());
					}

					List<Department> departments = departmentRepo.findAllById(departmentIds);

					In<Department> departmentInClause = cb.in(erf.get("department"));

					for (Department department : departments) {
						departmentInClause.value(department);
					}
					
					predicates.add(departmentInClause);
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_3) {

					List<Long> officeIds = new ArrayList<>();

					for (DataFilterValue filterValue : filterValues) {
						officeIds.add(filterValue.getFilterValueId());
					}

					List<OfficeLocation> officeLocations = officeLocationRepo.findAllById(officeIds);

					In<OfficeLocation> officeLocationInClause = cb.in(erf.get("workLocation"));

					for (OfficeLocation officeLocation : officeLocations) {
						officeLocationInClause.value(officeLocation);
					}
					
					predicates.add(officeLocationInClause);
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_4) {

					List<Long> entityIds = new ArrayList<>();

					for (DataFilterValue filterValue : filterValues) {
						entityIds.add(filterValue.getFilterValueId());
					}

					List<OrganizationEntity> entities = entityRepo.findAllById(entityIds);

					In<OrganizationEntity> entityInClause = cb.in(erf.get("entity"));

					for (OrganizationEntity entity : entities) {
						entityInClause.value(entity);
					}
					
					predicates.add(entityInClause);
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_5) {

					List<Long> projectIds = new ArrayList<>();

					for (DataFilterValue filterValue : filterValues) {
						projectIds.add(filterValue.getFilterValueId());
					}

					List<Project> projects = projectRepo.findAllById(projectIds);

					In<Project> projectInClause = cb.in(erf.get("project"));

					for (Project project : projects) {
						projectInClause.value(project);
					}
					
					predicates.add(projectInClause);
					
				}else if (filterValues != null && !filterValues.isEmpty()
						&& filter.getFilterType() == DataFilterType.TYPE_6) {

					List<Long> resourceAllocationIds = new ArrayList<>();

					for (DataFilterValue filterValue : filterValues) {
						resourceAllocationIds.add(filterValue.getFilterValueId());
					}

					List<ResourceAllocation> resourceAllocations = resourceAllocationRepo.findAllById(resourceAllocationIds);

					In<ResourceAllocation> resouceAllocationInClause = cb.in(erf.get("resourceAllocation"));

					for (ResourceAllocation resourceAllocation : resourceAllocations) {
						resouceAllocationInClause.value(resourceAllocation);
					}
					
					predicates.add(resouceAllocationInClause);
				}
								
				qr.where(predicates.toArray(new Predicate[]{}));
			}
		} else {
			throw new UnexpectedInternalError("Cannot determine the list of ERFs for this user. Please check if conditions are applied of not.");
		}

		TypedQuery<ERF> query = entityManager.createQuery(qr);

		return query.getResultList();
	}

}
