package com.in2it.irecruit.service;

import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Project;

public interface ProjectService {

	public List<Project> getAllProjects();
	
	public Project addProject(String projectName);

	public Project getProjectById(long id) throws UnexpectedInternalError;
	
}
