package com.in2it.irecruit.service.Impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.in2it.irecruit.constant.InterviewStatus;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.ExternalPanel;
import com.in2it.irecruit.model.InternalPanel;
import com.in2it.irecruit.model.InterviewDetail;
import com.in2it.irecruit.model.JobDescriptionResume;
import com.in2it.irecruit.repository.InterviewRepository;
import com.in2it.irecruit.service.InterviewService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 * InterviewServiceImpl
 */
@Service
public class InterviewServiceImpl implements InterviewService {

	@Autowired
	private InterviewRepository interviewRepo;

	@Override
	public InterviewDetail setInterviewDetail(InterviewDetail interviewDetail) throws UnexpectedInternalError {
		int countPrime = 0;

		for (InternalPanel internalPanel : interviewDetail.getInternalPanel()) {
			if (internalPanel.isPrime()) {
				countPrime++;
				if (countPrime > 1) {
					throw new UnexpectedInternalError("Cannot set multiple panel members as primary.");
				}
			}
		}

		countPrime = 0;

		for (ExternalPanel externalPanel : interviewDetail.getExternalPanel()) {
			if (externalPanel.isPrime()) {
				countPrime++;
				if (countPrime > 1) {
					throw new UnexpectedInternalError("Cannot set multiple panel members as primary.");
				}
			}
		}

		int count = interviewRepo.countByJobDescriptionResume(interviewDetail.getJobDescriptionResume());
		
		if (count == 0)
			interviewDetail.setStatus(InterviewStatus.ACTIVE);
		else
			interviewDetail.setStatus(InterviewStatus.INACTIVE);
		
		
		try {
			return interviewRepo.save(interviewDetail);
		} catch (DataIntegrityViolationException e) {
			throw new UnexpectedInternalError("Multiple assignments not allowed for a single round number.");
		}
	}

	@Override
	public List<InterviewDetail> getInterviewDetails(long jdResumeId) {
		JobDescriptionResume jobDescriptionResume = new JobDescriptionResume();
		jobDescriptionResume.setId(jdResumeId);

		return interviewRepo.findAllByJobDescriptionResume(jobDescriptionResume, Sort.by(Sort.Direction.ASC, "round"));
	}

	@Override
	public InterviewDetail scheduleInterview(long interviewDetailId, LocalDateTime interviewDateTime)
			throws UnexpectedInternalError {
		Optional<InterviewDetail> interviewDetailOpt = interviewRepo.findById(interviewDetailId);
		interviewDetailOpt.orElseThrow(() -> new UnexpectedInternalError("Cannot find interview detail with id : " + interviewDetailId));
		
		InterviewDetail interviewdetail = interviewDetailOpt.get();
		
		if(interviewdetail.getInterviewDateTime() != null) {
			interviewdetail.setStatus(InterviewStatus.RESCHEDULED);
		}
		
		interviewdetail.setInterviewDateTime(interviewDateTime);
		
		return interviewRepo.save(interviewdetail);
	}
}