package com.in2it.irecruit.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.AppPermissions;
import com.in2it.irecruit.model.AssignedPermission;


@Repository
public interface AssignedPermissionRepository extends JpaRepository<AssignedPermission, Long> {

	List<AssignedPermission> findByUser(long userId);

	List<AssignedPermission> findByUserAndAssigned(long id, boolean assigned);
	
	Optional<AssignedPermission> findByUserAndAppPermission(long user, AppPermissions appPermission);

}
