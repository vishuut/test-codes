package com.in2it.irecruit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.OfficeLocation;
import com.in2it.irecruit.model.State;
import com.in2it.irecruit.service.MetadataService;

@RestController
public class MetadataController {
	
	@Autowired
	private MetadataService metadataService;

	@GetMapping(value = "/country/find-all")
	public ResponseEntity<List<Map<String , Object>>> getAllCountries(){
		return new ResponseEntity<>(metadataService.getAllCountries(), HttpStatus.OK);
	}

	@GetMapping(value = "/country/find-by-nicename/{nicename}")
	public ResponseEntity<Country> getByNiceName(@PathVariable String nicename) throws UnexpectedInternalError {
		return new ResponseEntity<Country>(metadataService.getCountryByNiceName(nicename), HttpStatus.OK);
	}
	
	@GetMapping(value = "/state/find-by-country/{countryId}")
	public ResponseEntity<List<State>> getStatesByCountry(@PathVariable(name = "countryId") long countryId) throws UnexpectedInternalError {
		return new ResponseEntity<List<State>>(metadataService.getStatesByCountry(countryId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/state/find-by-id/{stateId}")
	public ResponseEntity<State> getStatesById(@PathVariable(name = "stateId") long stateId) throws UnexpectedInternalError {
		return new ResponseEntity<State>(metadataService.getStateById(stateId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/office-location/find-all")
	public ResponseEntity<List<OfficeLocation>> getAllOfficeLocations(){
		return new ResponseEntity<List<OfficeLocation>>(metadataService.getAllOfficeLocations(), HttpStatus.OK);
	}
	
	@GetMapping(value = "/office-location/find-by-country/{countryId}")
	public ResponseEntity<List<OfficeLocation>> getAllOfficeLocations(@PathVariable(name = "countryId") long countryId) throws UnexpectedInternalError{
		return new ResponseEntity<List<OfficeLocation>>(metadataService.getOfficeLocationsByCountry(countryId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/office-location/find-by-id/{locationId}")
	public ResponseEntity<OfficeLocation> getOfficeLocationById(@PathVariable(name = "locationId") long locationId) throws UnexpectedInternalError {
		return new ResponseEntity<OfficeLocation>(metadataService.getOfficeLocationById(locationId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/irecruit-api/metadata/get-for-erf-generation")
	@PreAuthorize("hasAuthority('ERF_GENERATE')")
	public ResponseEntity<Map<String, Object>> getMetadataForERFGeneration() {
		return new ResponseEntity<Map<String,Object>>(metadataService.getERFGenerationMetadata(), HttpStatus.OK);
	}
	
}
