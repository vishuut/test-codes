package com.in2it.irecruit.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringUtil {
	
	public static String toCommaSaperatedString(List<String> listOfString) {
		String result = "";
		if(listOfString != null && !listOfString.isEmpty()) {
			result = result.trim();
			result = String.join(",", listOfString);
		}
		return result;
	}
	
	public static String toCommaSaperatedString(String[] listOfString) {
		String result = "";
		if(listOfString != null && !(listOfString.length < 0)) {
			result = result.trim();
			result = String.join(",", listOfString);
		}
		return result;
	}
	
	public static List<String> toListOfString(String string, String saperator) {
		
		List<String> result = null;
		
		if(string != null && !string.isEmpty()) {
			result = Arrays.asList(string.split(saperator));
		}
		
		if(result == null) {
			result = new ArrayList<String>();
		}
		
		return result;
	}
	
	public static String[] toArrayOfString(String string, String saperator) {
		
		String[] result = null;
		
		if(string != null && !string.isEmpty()) {
			result = string.split(saperator);
		}
		
		if(result == null) {
			result = new String[1];
		}
		
		return result;
	}

}
