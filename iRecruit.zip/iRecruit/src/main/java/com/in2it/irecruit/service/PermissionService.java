package com.in2it.irecruit.service;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import com.in2it.irecruit.exception.UnexpectedInternalError;

public interface PermissionService {

	Map<String, List<String>> getCategoryWisePermission() throws UnexpectedInternalError;
	
	Map<String, Boolean> assignPermissionToUser(Principal userPrincipal, String permitedAction, String permitOn) throws UnexpectedInternalError;
	
	Map<String, Boolean> revokePermissionFromUser(Principal userPrincipal, String permitedAction, String permitOn) throws UnexpectedInternalError;
}
