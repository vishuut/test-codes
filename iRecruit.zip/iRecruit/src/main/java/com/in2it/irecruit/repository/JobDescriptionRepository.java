package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.JobDescription;

@Repository
public interface JobDescriptionRepository extends JpaRepository<JobDescription, Long> {
	
	List<JobDescription> findByErfAndCreatedBy(ERF erf, AppUser createdBy);

}
