package com.in2it.irecruit.service.Impl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.InterviewDetail;
import com.in2it.irecruit.model.JobDescription;
import com.in2it.irecruit.model.JobDescriptionRecruiter;
import com.in2it.irecruit.model.JobDescriptionResume;
import com.in2it.irecruit.model.ResumeData;
import com.in2it.irecruit.model.TrackLead;
import com.in2it.irecruit.repository.JobDescriptionRecruiterRepository;
import com.in2it.irecruit.repository.JobDescriptionRepository;
import com.in2it.irecruit.repository.JobDescriptionResumeRepository;
import com.in2it.irecruit.repository.projector.AppUserProjector;
import com.in2it.irecruit.service.JobDescriptionService;
import com.in2it.irecruit.service.TrackLeadService;
import com.in2it.irecruit.service.UserService;
import com.in2it.irecruit.wrapper.JobDescriptionListingWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionRecruiterWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionResumeWrapper;

@Service
public class JobDescriptionServiceImpl implements JobDescriptionService {

	@Autowired
	private JobDescriptionRepository jobDescriptionRepo;

	@Autowired
	private JobDescriptionResumeRepository jdResumeRepo;
	
	@Autowired
	private JobDescriptionRecruiterRepository jdRecruiterRepo;

	@Autowired
	private TrackLeadService trackLeadService;

	@Autowired
	UserService userService;

	@Override
	public List<JobDescription> addJobDescription(List<JobDescription> jobDescriptions, Principal userPrincipal) throws UnexpectedInternalError {
		AppUser createdBy = userService.getUserByEmail(userPrincipal.getName());
		isBudgetOrPositionExceeded(jobDescriptions, createdBy);
		
		for (JobDescription jobDescription : jobDescriptions) {
			jobDescription.setCreatedBy(createdBy);
		}
		jobDescriptionRepo.saveAll(jobDescriptions);
		return jobDescriptions;
	}

	private void isBudgetOrPositionExceeded(List<JobDescription> jobDescriptions, AppUser user) throws UnexpectedInternalError {
		if (jobDescriptions != null && !jobDescriptions.isEmpty()) {

			TrackLead trackLead = trackLeadService.findByErfAndUser(jobDescriptions.get(0).getErf(), user);

			List<JobDescription> existingJds = jobDescriptionRepo.findByErfAndCreatedBy(trackLead.getErf(), user);

			long existingJdBudget = 0;
			long existingJdPosition = 0;

			for (JobDescription jd : existingJds) {
				existingJdBudget += jd.getBudget();
				existingJdPosition += jd.getNoOfEmployee();
			}

			long newJdBudget = 0;
			long newJdPosition = 0;
			
			for (JobDescription jd : jobDescriptions) {
				newJdBudget += jd.getBudget();
				newJdPosition += jd.getNoOfEmployee();
			}
			

			if ((existingJdBudget + newJdBudget) > trackLead.getBudget()) {
				throw new UnexpectedInternalError("Cannot add JD(s). Budget exceeded.");
			} else if ((existingJdPosition + newJdPosition) > trackLead.getPosition()) {
				throw new UnexpectedInternalError("Cannot add JD(s). Positions exceeded.");
			}
			
		}

	}

	@Override
	public JobDescriptionResumeWrapper addResumeToJD(JobDescriptionResumeWrapper jdResumeData, Principal userPrincipal) throws UnexpectedInternalError {
		JobDescription jd = jdResumeData.getJobDescription();
		AppUser createdBy = userService.getUserByEmail(userPrincipal.getName());
		List<JobDescriptionResume> jdResumeMapping = null;
		List<ResumeData> mappedResumes = jdResumeData.getResumes();

		if (mappedResumes != null && !mappedResumes.isEmpty()) {
			jdResumeMapping = new ArrayList<JobDescriptionResume>();

			for (ResumeData resume : mappedResumes) {
				jdResumeMapping.add(new JobDescriptionResume(jd, resume, createdBy));
			}
		}
		
		try {
			jdResumeRepo.saveAll(jdResumeMapping);
		}catch (DataIntegrityViolationException e) {
			throw new UnexpectedInternalError("Multiple assignments not allowed for a single resume.");
		}

		return jdResumeData;
	}
	
	@Override
	public List<AppUserProjector> getAllRecruiters() {
		return userService.searchAllRecruiter();
	}

	@Override
	public JobDescriptionRecruiterWrapper attachRecruiterToJD(JobDescriptionRecruiterWrapper jobDescriptionRecruiterDta,Principal userPrincipal) throws UnexpectedInternalError {
		JobDescription jd = jobDescriptionRecruiterDta.getJobDescription();
		AppUser createdBy = userService.getUserByEmail(userPrincipal.getName());
		List<JobDescriptionRecruiter> jdRecruiterMapping = null;
		List<AppUser> mappedRecruiter = jobDescriptionRecruiterDta.getUser();
		
		if(mappedRecruiter != null && !mappedRecruiter.isEmpty()) {
			jdRecruiterMapping = new ArrayList<JobDescriptionRecruiter>();
			
			for (AppUser appUser : mappedRecruiter) {
				jdRecruiterMapping.add(new JobDescriptionRecruiter(jd , appUser, createdBy));
			}
		}
		
		try {
			jdRecruiterRepo.removeByJobDescription(jd);
			jdRecruiterRepo.saveAll(jdRecruiterMapping);
		}catch (DataIntegrityViolationException e) {
			throw new UnexpectedInternalError("Multiple assignments not allowed for a single recruiter.");
		}
		return jobDescriptionRecruiterDta;
	}

	@Override
	public List<JobDescriptionListingWrapper> getJobDescription() {
		List<JobDescription> allJobDescriptions = jobDescriptionRepo.findAll();
		List<JobDescriptionListingWrapper> jobDescriptionDataList = new ArrayList<>();
		
		for (JobDescription jd : allJobDescriptions) {
			Map<String , Object> erf = new HashMap<>();
			erf.put("erfNumber", jd.getErf().getErfNumber());
			erf.put("generateDate", jd.getErf().getGenerateDate());
			
			List<JobDescriptionRecruiter> jobDescriptionRecruiters = jdRecruiterRepo.findByJobDescription(jd);
			List<String> recruiterName = new ArrayList<>();
			for (JobDescriptionRecruiter jdr : jobDescriptionRecruiters) {
				recruiterName.add(jdr.getUser().getUsername());
			}
			
			
			jobDescriptionDataList.add(new JobDescriptionListingWrapper(erf,jd,0,recruiterName,0));
		}
		
		return jobDescriptionDataList;
	}

	@Override
	public List<JobDescriptionResume> getAttachedResumes(long jdId) {
		JobDescription jobDescription = new JobDescription();
		jobDescription.setId(jdId);

		List<JobDescriptionResume> jdResumesList = jdResumeRepo.findByJobDescription(jobDescription);

		return jdResumesList;
	}

	@Override
	public List<JobDescriptionRecruiter> getAssignedRecruiters(long jdId) {
		JobDescription jobDescription = new JobDescription();
		jobDescription.setId(jdId);

		List<JobDescriptionRecruiter> jobDescriptionRecruiters = jdRecruiterRepo.findByJobDescription(jobDescription);

		return jobDescriptionRecruiters;
	}
	
}
