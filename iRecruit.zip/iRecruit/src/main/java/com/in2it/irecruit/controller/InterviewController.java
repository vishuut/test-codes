package com.in2it.irecruit.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.constant.InterviewType;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.InterviewDetail;
import com.in2it.irecruit.service.InterviewService;

@RestController
@RequestMapping(value = "/irecruit-api/interview")
public class InterviewController {

    @Autowired
    private InterviewService interviewService;

    @GetMapping(value = "/get-interview-type")
    public ResponseEntity<List<InterviewType>> getInterviewTypes() {
        System.out.println(InterviewType.valueOf("ONLINE"));
        return ResponseEntity.ok(new ArrayList<>(Arrays.asList(InterviewType.values())));
    }

    @PostMapping(value = "/set-interview")
    public ResponseEntity<InterviewDetail> setInterview(@RequestBody InterviewDetail interviewDetail) throws UnexpectedInternalError{
        return ResponseEntity.ok(interviewService.setInterviewDetail(interviewDetail));
    }

    @GetMapping(value = "/get-interview-details/{jdResumeId}")
    public ResponseEntity<List<InterviewDetail>> getInterview(@PathVariable(name = "jdResumeId") long jdResumeId){
        return ResponseEntity.ok(interviewService.getInterviewDetails(jdResumeId));
    }

    @PostMapping(value = "/set-calendar/{interviewDetailId}")
    public ResponseEntity<InterviewDetail> setCalendar(@PathVariable(name = "interviewDetailId") long interviewDetailId , @RequestParam(value = "interviewDateTime") String interviewDateTime)throws UnexpectedInternalError{
        return ResponseEntity.ok(interviewService.scheduleInterview(interviewDetailId , LocalDateTime.parse(interviewDateTime)));
    }
    
}