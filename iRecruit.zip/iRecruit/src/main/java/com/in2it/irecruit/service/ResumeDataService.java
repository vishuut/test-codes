package com.in2it.irecruit.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.in2it.irecruit.exception.InvalidFileTypeException;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.ResumeData;

public interface ResumeDataService {
	
	ResumeData saveResumeData(HttpServletRequest request, MultipartFile file) throws InvalidFileTypeException, UnexpectedInternalError;
	Resource downloadResume(long resumeId);

}
