package com.in2it.irecruit.wrapper;

import java.util.List;
import java.util.Map;

import com.in2it.irecruit.model.JobDescription;

public class JobDescriptionListingWrapper {
	
	private Map<String, Object> erf;
	private JobDescription jobDescription;
	private int totalPositionHired;
	private List<String> recruiters;
	private int totalResumeSubmitted;	
	
	public JobDescriptionListingWrapper() {
		super();
	}

	public JobDescriptionListingWrapper(Map<String, Object> erf, JobDescription jobDescription, int totalPositionHired,
			List<String> recruiters, int totalResumeSubmitted) {
		super();
		this.erf = erf;
		this.jobDescription = jobDescription;
		this.totalPositionHired = totalPositionHired;
		this.recruiters = recruiters;
		this.totalResumeSubmitted = totalResumeSubmitted;
	}

	public Map<String, Object> getErf() {
		return erf;
	}

	public void setErf(Map<String, Object> erf) {
		this.erf = erf;
	}

	public JobDescription getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(JobDescription jobDescription) {
		this.jobDescription = jobDescription;
	}

	public int getTotalPositionHired() {
		return totalPositionHired;
	}

	public void setTotalPositionHired(int totalPositionHired) {
		this.totalPositionHired = totalPositionHired;
	}

	public List<String> getRecruiters() {
		return recruiters;
	}

	public void setRecruiters(List<String> recruiters) {
		this.recruiters = recruiters;
	}

	public int getTotalResumeSubmitted() {
		return totalResumeSubmitted;
	}

	public void setTotalResumeSubmitted(int totalResumeSubmitted) {
		this.totalResumeSubmitted = totalResumeSubmitted;
	}
	
}
