package com.in2it.irecruit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ResourceAllocation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "resouce_allocation_id")
	private long resouceAllocationId;

	@Column(name = "resouce_allocation_name")
	private String resouceAllocationName;

	public ResourceAllocation() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public long getResouceAllocationId() {
		return resouceAllocationId;
	}


	public void setResouceAllocationId(long resouceAllocationId) {
		this.resouceAllocationId = resouceAllocationId;
	}


	public String getResouceAllocationName() {
		return resouceAllocationName;
	}

	public void setResouceAllocationName(String resouceAllocationName) {
		this.resouceAllocationName = resouceAllocationName;
	}

	@Override
	public String toString() {
		return "ResourceAllocation [resouceAllocationId=" + resouceAllocationId + ", resouceAllocationName=" + resouceAllocationName + "]";
	}

}
