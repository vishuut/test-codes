package com.in2it.irecruit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "permission")
public class AppPermissions {

	@Id
	@Column(name = "permission_id")
	private long id;

	@Column(name = "category")
	private String permissionCategory;

	@Column(name = "type")
	private String permissionType;

	@Column(name = "auth_key", unique = true)
	private String permissionKey;

	public AppPermissions() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPermissionCategory() {
		return permissionCategory;
	}

	public void setPermissionCategory(String permissionCategory) {
		this.permissionCategory = permissionCategory;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	public String getPermissionKey() {
		return permissionKey;
	}

	public void setPermissionKey(String permissionKey) {
		this.permissionKey = permissionKey;
	}

	@Override
	public String toString() {
		return "AppPermissions [id=" + id + ", permissionCategory=" + permissionCategory + ", permissionType="
				+ permissionType + ", permissionKey=" + permissionKey + "]";
	}

}
