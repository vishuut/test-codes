package com.in2it.irecruit.service.abstractimpl;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.AssignedPermission;
import com.in2it.irecruit.repository.AssignedPermissionRepository;
import com.in2it.irecruit.repository.UserRepository;

public abstract class UserAndAssignedPermissionAbstractService {

	protected UserRepository userRepo;
	protected AssignedPermissionRepository assignedPermissionRepo;

	@Autowired
	public void setRepos(UserRepository userRepo, AssignedPermissionRepository permissionRepo) {
		this.userRepo = userRepo;
		this.assignedPermissionRepo = permissionRepo;
	}

	protected AppUser findUserByEmail(String email) throws UsernameNotFoundException {
		return userRepo.findByEmail(email);

	}

	protected AppUser findUserById(long userId) throws UsernameNotFoundException {
		Optional<AppUser> userOpt = userRepo.findById(userId);
		AppUser user = null;

		if (userOpt.isPresent()) {
			user = userOpt.get();
		} else {
			throw new UsernameNotFoundException("Cannot find user with the given email.");
		}

		return user;
	}

	protected Collection<? extends GrantedAuthority> buildUserAuthority(AppUser user) {
		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		List<AssignedPermission> permission = assignedPermissionRepo.findByUser(user.getId());
		for (AssignedPermission assignedPermission : permission) {
			setAuths.add(new SimpleGrantedAuthority(assignedPermission.getAppPermission().getPermissionKey()));
		}
		return setAuths;
	}

	protected List<AssignedPermission> findAssignedPermissionsByUser(AppUser user) {
		return assignedPermissionRepo.findByUserAndAssigned(user.getId(), true);
	}

}
