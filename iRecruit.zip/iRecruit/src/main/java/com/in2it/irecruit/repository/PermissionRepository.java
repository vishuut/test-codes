package com.in2it.irecruit.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.in2it.irecruit.model.AppPermissions;

public interface PermissionRepository extends JpaRepository<AppPermissions, Long> {

	List<AppPermissions> findByPermissionCategory(String permissionCategory);
	
	Optional<AppPermissions> findByPermissionCategoryAndPermissionType(String permissionCategory, String permissionType);
	
}
