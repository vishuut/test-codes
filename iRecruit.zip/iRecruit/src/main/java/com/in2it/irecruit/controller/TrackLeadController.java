package com.in2it.irecruit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.TrackLead;
import com.in2it.irecruit.service.TrackLeadService;

@RestController
@RequestMapping(value = "/irecruit-api/tracklead")
public class TrackLeadController {
	
	@Autowired
	private TrackLeadService trackLeadService;
	
	@PostMapping(value = "/assign-tracklead")
	public ResponseEntity<List<TrackLead>> saveTrackLead(@RequestBody List<TrackLead> trackLead) throws UnexpectedInternalError{
		return new ResponseEntity<List<TrackLead>>(trackLeadService.saveTrackLead(trackLead),HttpStatus.OK);
	}
	
	@GetMapping(value = "/get-trackleads/{erfId}")
	public ResponseEntity<List<TrackLead>> getTrackLeadsForErf(@PathVariable(name = "erfId") long erfId) throws UnexpectedInternalError{
		return ResponseEntity.ok().body(trackLeadService.getTrackleadsForErf(erfId));
	}

}
