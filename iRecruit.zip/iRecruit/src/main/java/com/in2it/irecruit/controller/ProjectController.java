package com.in2it.irecruit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Project;
import com.in2it.irecruit.service.ProjectService;

@RestController
@RequestMapping(value = "/irecruit-api/project")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@GetMapping(value = "/get-all")
	public ResponseEntity<List<Project>> getAllProjects(){
		return new ResponseEntity<List<Project>>(projectService.getAllProjects(), HttpStatus.OK);
	}
	
	@GetMapping(value = "/get-all/{id}")
	public ResponseEntity<Project> getAllProjects(@PathVariable(value = "id") long id) throws UnexpectedInternalError{
		return new ResponseEntity<Project>(projectService.getProjectById(id), HttpStatus.OK);
	}
	
	@PostMapping(value = "/add")
	public ResponseEntity<Project> addNewProject(@RequestParam(name = "projectName") String projectName){
		return new ResponseEntity<Project>(projectService.addProject(projectName), HttpStatus.OK);
	}
}
