package com.in2it.irecruit.model;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

/*
* this bean class is used to store the 'User' info of 'ERF' business model.
* 
* @author subhash kumar
*/

@Entity
@Table(name = "app_user")
public class AppUser implements Serializable, UserDetails {

	private static final long serialVersionUID = -1787098634409657555L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_id")
	private long id;

	private String sapId;

	@Column(name = "salutation", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String salutation;

	@Column(name = "first_name", columnDefinition = "VARCHAR(255) default ''")
	private String firstName;

	@Column(name = "last_name", columnDefinition = "VARCHAR(255) default ''")
	private String lastName;

	@Column(name = "date_of_birth")
	@JsonIgnore
	private LocalDate dateOfBirth;

	@Column(name = "band", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String band;

	@Column(name = "sub_band", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String subBand;

	@Column(name = "job_title", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String jobTitle;

	@OneToOne
	@JsonIgnore
	private Department department;
	
	@JsonIgnore
	private boolean recruiter;

	@Column(name = "domain", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String domain;

	@Column(name = "sub_domain", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String subDomain;

	@OneToOne
	@JsonIgnore
	private OrganizationEntity entity;

	@OneToOne
	@JsonIgnore
	private Country baseLocation;

	@OneToOne
	@JsonIgnore
	private OfficeLocation currentLocation;

	@Column(name = "hire_date")
	@JsonIgnore
	private Date hireDate;

	@Column(name = "active", columnDefinition = "tinyint(1) default 1")
	@JsonIgnore
	private boolean active = true;

	@Column(name = "gender", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String gender;

	@Column(name = "marital_status", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String maritalStatus;

	@Column(name = "nationality", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String nationality;

	@OneToOne
	@JsonIgnore
	private Country country;

	@Column(name = "manager_id", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String managerId;

	@Column(name = "matrix_manager_id", columnDefinition = "VARCHAR(255) default ''")
	@JsonIgnore
	private String matrixManagerId;

	@Column(name = "bu_hr_id", columnDefinition = "int(11) default 0")
	@JsonIgnore
	private int buHrId = 0;

	@Column(name = "user_email", columnDefinition = "VARCHAR(255) default ''", unique = true)
	@NotNull(message = "Email is compulsory")
	@JsonIgnore
	private String email;

	@OneToOne
	@JsonIgnore
	private ResourceAllocation resourceAllocation;

	@OneToOne
	@JsonIgnore
	private Project project;

	@Column(name = "user_name", columnDefinition = "VARCHAR(255) default ''")
	private String username;

	@Column(name = "password", columnDefinition = "VARCHAR(255) default ''")
	@Length(min = 5, message = "Role should be at least 5 is compulsory")
	@JsonProperty(access = Access.WRITE_ONLY)
	private String password;

	@Transient
	@JsonIgnore
	public Collection<? extends GrantedAuthority> authorities;

	public AppUser() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSapId() {
		return sapId;
	}

	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public String getSubBand() {
		return subBand;
	}

	public void setSubBand(String subBand) {
		this.subBand = subBand;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public boolean isRecruiter() {
		return recruiter;
	}

	public void setRecruiter(boolean recruiter) {
		this.recruiter = recruiter;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public OrganizationEntity getEntity() {
		return entity;
	}

	public void setEntity(OrganizationEntity entity) {
		this.entity = entity;
	}

	public Country getBaseLocation() {
		return baseLocation;
	}

	public void setBaseLocation(Country baseLocation) {
		this.baseLocation = baseLocation;
	}

	public OfficeLocation getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(OfficeLocation currentLocation) {
		this.currentLocation = currentLocation;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getMatrixManagerId() {
		return matrixManagerId;
	}

	public void setMatrixManagerId(String matrixManagerId) {
		this.matrixManagerId = matrixManagerId;
	}

	public int getBuHrId() {
		return buHrId;
	}

	public void setBuHrId(int buHrId) {
		this.buHrId = buHrId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ResourceAllocation getResourceAllocation() {
		return resourceAllocation;
	}

	public void setResourceAllocation(ResourceAllocation resourceAllocation) {
		this.resourceAllocation = resourceAllocation;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
		this.authorities = authorities;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.authorities;
	}

	@Override
	@JsonIgnore
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	@JsonIgnore
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	@JsonIgnore
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	@JsonIgnore
	public boolean isEnabled() {
		return active;
	}

	@Override
	public String toString() {
		return "AppUser [id=" + id + ", sapId=" + sapId + ", salutation=" + salutation + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth + ", band=" + band + ", subBand=" + subBand
				+ ", jobTitle=" + jobTitle + ", department=" + department + ", domain=" + domain + ", subDomain="
				+ subDomain + ", entity=" + entity + ", baseLocation=" + baseLocation + ", currentLocation="
				+ currentLocation + ", hireDate=" + hireDate + ", active=" + active + ", gender=" + gender
				+ ", maritalStatus=" + maritalStatus + ", nationality=" + nationality + ", country=" + country
				+ ", managerId=" + managerId + ", matrixManagerId=" + matrixManagerId + ", buHrId=" + buHrId
				+ ", email=" + email + ", resourceAllocation=" + resourceAllocation + ", project=" + project
				+ ", username=" + username + ", password=" + password + ", authorities=" + authorities + "]";
	}
}
