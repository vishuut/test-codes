package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 * InternalPanel
 */
@Entity
public class InternalPanel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @OneToOne
    private AppUser employee;

    private boolean prime;

    public InternalPanel() {
    }

    public InternalPanel(AppUser employee, boolean prime) {
        this.employee = employee;
        this.prime = prime;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AppUser getEmployee() {
        return this.employee;
    }

    public void setEmployee(AppUser employee) {
        this.employee = employee;
    }

    public boolean isPrime() {
        return this.prime;
    }

    public boolean getPrime() {
        return this.prime;
    }

    public void setPrimary(boolean prime) {
        this.prime = prime;
    }

    @Override
    public String toString() {
        return "{" + " id='" + id + "'" + ", employee='" + employee + "'" + ", primary='" + prime + "'" + "}";
    }
}