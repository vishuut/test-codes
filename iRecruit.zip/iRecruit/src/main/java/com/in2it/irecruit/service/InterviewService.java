package com.in2it.irecruit.service;

import java.time.LocalDateTime;
import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.InterviewDetail;

/**
 * InterviewService
 */
public interface InterviewService {

	InterviewDetail setInterviewDetail(InterviewDetail interviewDetail) throws UnexpectedInternalError;
	List<InterviewDetail> getInterviewDetails(long jdResumeId);
	InterviewDetail scheduleInterview(long interviewDetailId, LocalDateTime interviewDateTime) throws UnexpectedInternalError;
}