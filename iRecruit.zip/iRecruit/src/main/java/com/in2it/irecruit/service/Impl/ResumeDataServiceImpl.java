package com.in2it.irecruit.service.Impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.in2it.irecruit.exception.InvalidFileTypeException;
import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.ResumeData;
import com.in2it.irecruit.model.State;
import com.in2it.irecruit.repository.CountryRepository;
import com.in2it.irecruit.repository.ResumeDataRepository;
import com.in2it.irecruit.repository.StateRepository;
import com.in2it.irecruit.service.ERFFilesService;
import com.in2it.irecruit.service.ResumeDataService;

@Service
@PropertySource("classpath:application.properties")
public class ResumeDataServiceImpl implements ResumeDataService {
	
	private String resumeUploadRootDir;
	
	private ERFFilesService filesService;
	private ResumeDataRepository resumeDataRepo;
	private CountryRepository countryRepo;
	private StateRepository stateRepo;
	
	@Autowired
	public ResumeDataServiceImpl(@Value("${erf.resume.upload.directory}") String uploadDir, ERFFilesService fileService, ResumeDataRepository resumeDataRepo, CountryRepository countryRepo, StateRepository stateRepo) {
		this.resumeUploadRootDir = uploadDir;
		this.filesService = fileService;
		this.resumeDataRepo = resumeDataRepo;
		this.countryRepo = countryRepo;
		this.stateRepo = stateRepo;
	}

	@Override
	public ResumeData saveResumeData(HttpServletRequest request, MultipartFile file) throws InvalidFileTypeException, UnexpectedInternalError {
		
		if(!isValidFileType(file.getOriginalFilename())) {
			throw new InvalidFileTypeException("Only PDF, DOC, DOCX and TXT files are allowed.");
		}else {
			String fileName = "resume-" + String.valueOf(System.currentTimeMillis());
			String filePath = filesService.saveFileFromMultipartFormData(file, resumeUploadRootDir, fileName);
			
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String address = request.getParameter("address");
			String city = request.getParameter("city");
			long stateId = Long.valueOf(request.getParameter("stateId"));
			String zip = request.getParameter("zip");
			long countryId = Long.valueOf(request.getParameter("countryId"));
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			String domain = request.getParameter("domain");
			
			Optional<Country> countryOpt = countryRepo.findById(countryId);
			Optional<State> stateOpt = stateRepo.findById(stateId);
			
			if(!countryOpt.isPresent()) {
				throw new UnexpectedInternalError("Cannot associate country with remume data. Cannot find country with ID: " + countryId + ". Operation failed.");
			}else if(!stateOpt.isPresent()){
				throw new UnexpectedInternalError("Cannot associate state with remume data. Cannot find state with ID: " + stateId + ". Operation failed.");
			}else {
				phone = "+" + countryOpt.get().getPhonecode() + phone;
			}
			
			ResumeData resumeData = new ResumeData(firstName, lastName, address, city, stateOpt.get(), zip, fileName, filePath, email, phone, domain);
			resumeDataRepo.save(resumeData);
			return resumeData;			
		}
	}
	
	@Override
	public Resource downloadResume(long resumeId) {
		Optional<ResumeData> resumeDataOpt = resumeDataRepo.findById(resumeId);
		Resource resumeFileResource = null;
		
		if(resumeDataOpt.isPresent()) {
			resumeFileResource = filesService.getFileAsResource(resumeDataOpt.get().getResumeFilePath());
		}
		
		return resumeFileResource;
	}
	
	private boolean isValidFileType(String fileName) {
		String extention = FilenameUtils.getExtension(fileName);
		if(extention.equalsIgnoreCase("pdf") || extention.equalsIgnoreCase("doc") || extention.equalsIgnoreCase("docx") || extention.equalsIgnoreCase("txt")) {
			return true;
		}
		
		return false;
	}

}
