package com.in2it.irecruit.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.repository.projector.AppUserProjector;

public interface UserService {
	Map<String, Object> getUserDetailsWithPermissions(String email);

	AppUser getUserByEmail(String email);
	
	List<AppUserProjector> searchBySapId(String sapId);
	
	List<AppUserProjector> searchByUserName(String userName);
	
	List<AppUserProjector> searchAllRecruiter();

	Optional<AppUser> getUserById(long id);
}
