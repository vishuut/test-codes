package com.in2it.irecruit.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.service.PermissionService;

@RestController
@RequestMapping(value = "/irecruit-api/app-permission")
public class PermissionController {
	
	@Autowired
	PermissionService permissionService;
	
	@GetMapping(value = "/get-categorywise")
	public ResponseEntity<Map<String, List<String>>> getCategoryWisePermissions() throws UnexpectedInternalError {
		return new ResponseEntity<>(permissionService.getCategoryWisePermission(), HttpStatus.OK);
	}
	
	@PostMapping(value = "/assign-to-user")
	public ResponseEntity<Map<String, Boolean>> assignPermission(Principal userPrincipal, @RequestParam(name = "permitAction") String permitAction, @RequestParam(name = "permitOn") String permitOn) throws UnexpectedInternalError {
		return new ResponseEntity<>(permissionService.assignPermissionToUser(userPrincipal, permitAction, permitOn), HttpStatus.OK);
	}
	
	@PostMapping(value = "/revoke-from-user")
	public ResponseEntity<Map<String, Boolean>> revokePermission(Principal userPrincipal, @RequestParam(name = "revokingAction") String revokingAction, @RequestParam(name = "revokeOn") String revokeOn) throws UnexpectedInternalError {
		return new ResponseEntity<>(permissionService.revokePermissionFromUser(userPrincipal, revokingAction, revokeOn), HttpStatus.OK);
	}
}
