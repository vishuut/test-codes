package com.in2it.irecruit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "assigned_permission")
public class AssignedPermission {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "assigned_permission_id")
	private long id;

	@Column(name = "user_id")
	private long user;

	@OneToOne(fetch = FetchType.EAGER)
	private AppPermissions appPermission;

	@Column(name = "assigned")
	private boolean assigned;

	public AssignedPermission() {
		super();
	}
	
	public AssignedPermission(long user, AppPermissions appPermission, boolean assigned) {
		super();
		this.user = user;
		this.appPermission = appPermission;
		this.assigned = assigned;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUser() {
		return user;
	}

	public void setUser(long user) {
		this.user = user;
	}

	public AppPermissions getAppPermission() {
		return appPermission;
	}

	public void setAppPermission(AppPermissions appPermission) {
		this.appPermission = appPermission;
	}

	public boolean isAssigned() {
		return assigned;
	}

	public void setAssigned(boolean assigned) {
		this.assigned = assigned;
	}

	@Override
	public String toString() {
		return "AssignedPermission [id=" + id + ", user=" + user + ", permission=" + appPermission + ", assigned="
				+ assigned + "]";
	}

}
