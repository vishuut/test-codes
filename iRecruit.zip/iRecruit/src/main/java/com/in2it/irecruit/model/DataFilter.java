package com.in2it.irecruit.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.in2it.irecruit.constant.DataFilterType;

@Entity
@Table(name = "data_filter")
public class DataFilter {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Enumerated(EnumType.ORDINAL)
	private DataFilterType filterType;
	
	private boolean active;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private AppUser user;
	
	@OneToMany(mappedBy = "dataFilter", fetch = FetchType.EAGER)
	private List<DataFilterValue> dataFilterValues;
	
	public DataFilter() {}
	
	public DataFilter(DataFilterType filterType, AppUser user, boolean active, List<DataFilterValue> dataFilterValues) {
		this.filterType = filterType;
		this.user = user;
		this.active = active;
		this.dataFilterValues = dataFilterValues;
	}
	
	public DataFilter(DataFilterType filterType, AppUser user, boolean active) {
		this.filterType = filterType;
		this.user = user;
		this.active = active;
	}
	
	public DataFilter(DataFilterType filterType, AppUser user) {
		this.filterType = filterType;
		this.user = user;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public DataFilterType getFilterType() {
		return filterType;
	}

	public void setFilterType(DataFilterType filterType) {
		this.filterType = filterType;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public AppUser getUser() {
		return user;
	}

	public void setUser(AppUser user) {
		this.user = user;
	}
	
	public List<DataFilterValue> getDataFilterValues() {
		return dataFilterValues;
	}

	public void setDataFilterValues(List<DataFilterValue> dataFilterValues) {
		this.dataFilterValues = dataFilterValues;
	}

	@Override
	public String toString() {
		return "DataFilter [id=" + id + ", filterType=" + filterType + ", active=" + active + ", dataFilterValues="
				+ dataFilterValues + "]";
	}
			
}
