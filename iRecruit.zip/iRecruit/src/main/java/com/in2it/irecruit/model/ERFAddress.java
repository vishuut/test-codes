package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ERFAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long id;

	@OneToOne
	private Country country;

	@OneToOne
	private State state;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private ERF erf;

	private String zipCode;

	private String addressLineOne;
	
	private String addressLineTwo;
	
	@JsonIgnore
	private String addressType;

	public ERFAddress() {}

	public ERFAddress(Country country, State state, ERF erf, String zipCode, String addressLineOne, String addressLineTwo, String addressType) {
		super();
		this.country = country;
		this.state = state;
		this.erf = erf;
		this.zipCode = zipCode;
		this.addressLineOne = addressLineOne;
		this.addressLineTwo = addressLineTwo;
		this.addressType = addressType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public ERF getErf() {
		return erf;
	}

	public void setErf(ERF erf) {
		this.erf = erf;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}
	
	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	@Override
	public String toString() {
		return "ERFAddress [id=" + id + ", country=" + country + ", state=" + state + ", erf=" + erf + ", zipCode="
				+ zipCode + ", addressLineOne=" + addressLineOne + ", addressLineTwo=" + addressLineTwo
				+ ", addressType=" + addressType + "]";
	}
		
}
