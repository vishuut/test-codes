package com.in2it.irecruit.service.Impl;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.ERFAddress;
import com.in2it.irecruit.repository.ERFRepository;
import com.in2it.irecruit.service.ERFService;
import com.in2it.irecruit.service.UserService;

@Service
public class ERFServiceImpl implements ERFService {

	@Autowired
	private ERFRepository erfRepo;

	@Autowired
	private UserService userService;

	@Override
	public ERF saveERF(ERF erf, Principal userPrincipal) {

		// generate date
		LocalDate localDate = LocalDate.now();
		erf.setGenerateDate(localDate);

		AppUser user = userService.getUserByEmail(userPrincipal.getName());
		erf.setErfStatus("OPEN");
		erf.setCreatedBy(user);
		erf.setDepartment(user.getDepartment());
		
		for(ERFAddress add: erf.getSourceAddresses()) {
			add.setErf(erf);
		}
		
		for(ERFAddress add: erf.getWorkAddresses()) {
			add.setErf(erf);
		}
		
		return erfRepo.save(erf);
	}

	@Override
	public List<ERF> viewERF(Principal userPrincipal) throws UnexpectedInternalError {
		return erfRepo.findAll();
	}

	@Override
	public ERF viewERFById(long erfId) throws UnexpectedInternalError {
		Optional<ERF> erfOpt = erfRepo.findById(erfId);
		erfOpt.orElseThrow(() -> new UnexpectedInternalError("Cannot find ERF with ID: " + erfId));
		return erfOpt.get();
	}
}
