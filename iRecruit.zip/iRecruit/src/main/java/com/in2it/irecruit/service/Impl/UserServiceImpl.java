package com.in2it.irecruit.service.Impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.AssignedPermission;
import com.in2it.irecruit.repository.projector.AppUserProjector;
import com.in2it.irecruit.service.UserService;
import com.in2it.irecruit.service.abstractimpl.UserAndAssignedPermissionAbstractService;

@Service
public class UserServiceImpl extends UserAndAssignedPermissionAbstractService implements UserDetailsService, UserService {
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		AppUser user = findUserByEmail(email);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		Collection<? extends GrantedAuthority> authorities = buildUserAuthority(user);
		user.setAuthorities(authorities);
		return new User(user.getEmail(), user.getPassword(), user.isEnabled(), user.isAccountNonExpired(), user.isCredentialsNonExpired(), user.isAccountNonLocked(), user.getAuthorities());
	}
	
	@Override
	public AppUser getUserByEmail(String email) {
		return findUserByEmail(email);
	}

	@Override
	public Map<String, Object> getUserDetailsWithPermissions(String email) {
		AppUser user = findUserByEmail(email);
		List<AssignedPermission> permissions = findAssignedPermissionsByUser(user);
		
		Map<String, Object> userDetailsWithPermissions = new HashMap<>();
		Map<String, String> userData = new HashMap<>();
		userData.put("name", user.getUsername());
		userData.put("email", user.getEmail());
		userData.put("designation", user.getJobTitle());
		userData.put("department", user.getDepartment().getDepartmentName());
		userData.put("sapId", user.getSapId());
		userData.put("id", String.valueOf(user.getId()));
		
		Map<String, List<String>> userPermissions = new HashMap<>();
		for (AssignedPermission permission : permissions) {
			
			String key = permission.getAppPermission().getPermissionCategory();
			String value = permission.getAppPermission().getPermissionType();
			
			if(userPermissions.containsKey(key)) {
				userPermissions.get(key).add(value);
			}else {
				List<String> valueList = new ArrayList<>();
				valueList.add(value);
				userPermissions.put(key, valueList);
			}
		}
		
		userDetailsWithPermissions.put("userData", userData);
		userDetailsWithPermissions.put("permisions", userPermissions);
		return userDetailsWithPermissions;
	}
	
	@Override
	public List<AppUserProjector> searchBySapId(String sapId) {
		List<AppUserProjector> userList = userRepo.readBySapIdStartsWith(sapId);
		
		if(userList == null) {
			userList = new ArrayList<AppUserProjector>();
		}
		
		return userList;
	}
	
	@Override
	public List<AppUserProjector> searchByUserName(String userName) {
		List<AppUserProjector> userList = userRepo.readByUsernameContainingIgnoreCase(userName);

		if(userList == null) {
			userList = new ArrayList<AppUserProjector>();
		}
		
		return userList;
	}
	
	@Override
	public List<AppUserProjector> searchAllRecruiter() {	
		return userRepo.readByRecruiter(true);
	}

	@Override
	public Optional<AppUser> getUserById(long id) {
		// TODO Auto-generated method stub
		return userRepo.findById(id);
	}

}
