package com.in2it.irecruit.repository;

import java.util.List;

import com.in2it.irecruit.model.InterviewDetail;
import com.in2it.irecruit.model.JobDescriptionResume;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * InterviewRepository
 */
@Repository
public interface InterviewRepository extends JpaRepository<InterviewDetail, Long>{

    List<InterviewDetail> findAllByJobDescriptionResume(JobDescriptionResume jdDescriptionResume);
    List<InterviewDetail> findAllByJobDescriptionResume(JobDescriptionResume jdDescriptionResume, Sort sort);
    int countByJobDescriptionResume(JobDescriptionResume jdDescriptionResume);
}