package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ExternalPanel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String firstName;
    private String lastName;
    private String email;
    private String contact;
    private boolean prime;

    public ExternalPanel() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return this.contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public boolean isPrime() {
        return this.prime;
    }

    public boolean getPrime() {
        return this.prime;
    }

    public void setPrimary(boolean prime) {
        this.prime = prime;
    }

    @Override
    public String toString() {
        return "{" + " id='" + id + "'" + ", firstName='" + firstName + "'" + ", lastName='" + lastName + "'"
                + ", email='" + email + "'" + ", contact='" + contact + "'" + ", primary='" + prime + "'" + "}";
    }

}
