package com.in2it.irecruit.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.in2it.irecruit.model.ResumeData;

public interface ResumeDataRepository extends JpaRepository<ResumeData, Long> {

}
