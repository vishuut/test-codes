package com.in2it.irecruit.repository;

import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;

public interface CustomERFRepository {
	
	List<ERF> findERFByFiltersCriteria(AppUser user) throws UnexpectedInternalError;
	
}
