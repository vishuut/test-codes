package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(
		name="jd_recruiter_mapping",
		uniqueConstraints= @UniqueConstraint(columnNames={"job_description_id", "user_id"})
)
public class JobDescriptionRecruiter {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@OneToOne
	@JoinColumn(name = "job_description_id")
	private JobDescription jobDescription;
	
	@OneToOne
	@JoinColumn(name = "user_id")
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private AppUser user;
	
	@OneToOne
	@JsonIgnore
	private AppUser createdBy;

	public JobDescriptionRecruiter() {
		super();
	}

	public JobDescriptionRecruiter(JobDescription jobDescription, AppUser user, AppUser createdBy) {
		super();
		this.jobDescription = jobDescription;
		this.user = user;
		this.createdBy = createdBy;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@JsonIgnore
	public JobDescription getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(JobDescription jobDescription) {
		this.jobDescription = jobDescription;
	}

	public AppUser getUser() {
		return user;
	}

	public void setUser(AppUser user) {
		this.user = user;
	}

	public AppUser getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AppUser createdBy) {
		this.createdBy = createdBy;
	}
		

}
