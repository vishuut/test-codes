package com.in2it.irecruit.exception;

public class UnexpectedInternalError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnexpectedInternalError() {
		super("Internal Server Exception");
	}

	public UnexpectedInternalError(String message) {
		super(message);
	}

}
