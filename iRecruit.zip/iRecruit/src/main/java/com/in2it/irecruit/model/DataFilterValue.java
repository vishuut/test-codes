package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "data_filter_value")
public class DataFilterValue {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private long filterValueId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private DataFilter dataFilter;

	public DataFilterValue() {}

	public DataFilterValue(long filterValueId, DataFilter dataFilter) {
		this.filterValueId = filterValueId;
		this.dataFilter = dataFilter;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getFilterValueId() {
		return filterValueId;
	}

	public void setFilterValueId(long filterValueId) {
		this.filterValueId = filterValueId;
	}

	public DataFilter getDataFilter() {
		return dataFilter;
	}

	public void setDataFilter(DataFilter dataFilter) {
		this.dataFilter = dataFilter;
	}

	@Override
	public String toString() {
		return "DataFilterValue [id=" + id + ", filterValueId=" + filterValueId + ", dataFilter=" + dataFilter + "]";
	}
}
