package com.in2it.irecruit.constant;

public enum InterviewStatus {
	
	ACTIVE,
	INACTIVE,
	RESCHEDULED,
	CANCELED,
	DELETED,
	CANDIDATEBACKEDOUT;
}
