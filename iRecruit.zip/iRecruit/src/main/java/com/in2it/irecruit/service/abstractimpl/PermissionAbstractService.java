package com.in2it.irecruit.service.abstractimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppPermissions;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.AssignedPermission;
import com.in2it.irecruit.repository.AssignedPermissionRepository;
import com.in2it.irecruit.repository.PermissionRepository;

public abstract class PermissionAbstractService {
	
	protected enum PermissionCategory {
		ERF, OFFER, INTERVIEW, RESUME, RECRUITER, ROLE, PANEL, FEEDBACK
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PermissionAbstractService.class.getName());
	
	private PermissionRepository permissionRepo;
	private AssignedPermissionRepository permissionManagerRepo;
	
	@Autowired
	public void setRepos(PermissionRepository permissionRepo, AssignedPermissionRepository permissionManagerRepo) {
		this.permissionRepo = permissionRepo;
		this.permissionManagerRepo = permissionManagerRepo;
	}
	
	private AppPermissions getPermissionByCategoryAndType(String category, String type) {
		Optional<AppPermissions> permissionOpt = permissionRepo.findByPermissionCategoryAndPermissionType(category, type);
		
		if(permissionOpt.isPresent()) {
			return permissionOpt.get();
		}else {
			return null;
		}
	}
	
	private AssignedPermission findAssignedPermissionByUserAndAppPermission(AppUser user, AppPermissions permission) {
		Optional<AssignedPermission> assignedPermissionOpt = permissionManagerRepo.findByUserAndAppPermission(user.getId(), permission);
		
		if(assignedPermissionOpt.isPresent()) {
			return assignedPermissionOpt.get();
		}else {
			return null;
		}
	}
	
	protected AppPermissions findByPermissionId(long permissionId) throws UnexpectedInternalError {
		Optional<AppPermissions> permissionOpt = permissionRepo.findById(permissionId);
		AppPermissions permission = null;
		
		if(permissionOpt.isPresent()) {
			permission = permissionOpt.get();
		}else {
			LOGGER.error("Permission Error: Cannot find permission with ID: " + permissionId);
			throw new UnexpectedInternalError("Undefined Permission.");
		}
		
		return permission;
	}
	
	protected List<String> getApplicablePermissionsByCategory(String category) throws UnexpectedInternalError {
		PermissionCategory permissionCategory = null;
		List<String> applicablePermissions = null;
		
		try {
			permissionCategory = PermissionCategory.valueOf(category.toUpperCase());
			applicablePermissions = new ArrayList<String>();
		}catch(IllegalArgumentException ex) {
			LOGGER.error("Permission Error: Cannot find permission with category: " + category);
			throw new UnexpectedInternalError("Invalid permission category: " + category);
		}
		
		List<AppPermissions> permissions = permissionRepo.findByPermissionCategory(permissionCategory.toString());
		
		for(AppPermissions permission: permissions) {
			applicablePermissions.add(permission.getPermissionType());
		}
		
		return applicablePermissions;
	}
	
	protected boolean allocatePermissionToUser(AppUser user, String category, String type) throws UnexpectedInternalError {
		PermissionCategory permissionCategory = null;
		
		try {
			permissionCategory = PermissionCategory.valueOf(category.toUpperCase());
		}catch(IllegalArgumentException ex) {
			LOGGER.error("Permission Error: Cannot find permission with category: " + category);
			throw new UnexpectedInternalError("Invalid permission category: " + category);
		}
		
		AppPermissions permission = getPermissionByCategoryAndType(permissionCategory.toString(), type.toUpperCase());
		
		if(permission == null) {
			throw new UnexpectedInternalError("Invalid permission combination: Category= " + category + " and Type= " + type);
		}
		
		AssignedPermission assignedPermission = findAssignedPermissionByUserAndAppPermission(user, permission);
		
		if(assignedPermission != null) {
			if(assignedPermission.isAssigned()) {
				return true;
			}else {
				assignedPermission.setAssigned(true);
				permissionManagerRepo.save(assignedPermission);
				return true;
			}
		}else {
			assignedPermission = new AssignedPermission(user.getId(), permission, true);
			permissionManagerRepo.save(assignedPermission);
		}
		
		return false;
	}
	
	protected boolean unallocatePermissionFromUser(AppUser user, String category, String type) throws UnexpectedInternalError{
		PermissionCategory permissionCategory = null;
		
		try {
			permissionCategory = PermissionCategory.valueOf(category.toUpperCase());
		}catch(IllegalArgumentException ex) {
			LOGGER.error("Permission Error: Cannot find permission with category: " + category);
			throw new UnexpectedInternalError("Invalid permission category: " + category);
		}
		
		AppPermissions permission = getPermissionByCategoryAndType(permissionCategory.toString(), type.toUpperCase());
		
		if(permission == null) {
			throw new UnexpectedInternalError("Invalid permission combination: Category= " + category + " and Type= " + type);
		}
		
		AssignedPermission assignedPermission = findAssignedPermissionByUserAndAppPermission(user, permission);
		
		if(assignedPermission != null) {
			if(!assignedPermission.isAssigned()) {
				return true;
			}else {
				assignedPermission.setAssigned(false);
				permissionManagerRepo.save(assignedPermission);
				return true;
			}
		}else {
			throw new UnexpectedInternalError("The given user was never assigned this permission.");
		}
	}
	
}
