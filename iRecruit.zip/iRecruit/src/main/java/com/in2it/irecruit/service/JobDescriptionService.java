package com.in2it.irecruit.service;

import java.security.Principal;
import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.JobDescription;
import com.in2it.irecruit.model.JobDescriptionRecruiter;
import com.in2it.irecruit.model.JobDescriptionResume;
import com.in2it.irecruit.model.ResumeData;
import com.in2it.irecruit.repository.projector.AppUserProjector;
import com.in2it.irecruit.wrapper.JobDescriptionListingWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionRecruiterWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionResumeWrapper;

public interface JobDescriptionService {

	List<JobDescription> addJobDescription(List<JobDescription> jobDescriptions, Principal userPrincipal) throws UnexpectedInternalError;

	JobDescriptionResumeWrapper addResumeToJD(JobDescriptionResumeWrapper resumeData, Principal userPrincipal) throws UnexpectedInternalError;
	
	List<AppUserProjector> getAllRecruiters();

	JobDescriptionRecruiterWrapper attachRecruiterToJD(JobDescriptionRecruiterWrapper jobDescriptionRecruiterDta, Principal userPrincipal) throws UnexpectedInternalError;

	List<JobDescriptionListingWrapper> getJobDescription();

	List<JobDescriptionResume> getAttachedResumes(long jdId);

	public List<JobDescriptionRecruiter> getAssignedRecruiters(long jdId);

}
