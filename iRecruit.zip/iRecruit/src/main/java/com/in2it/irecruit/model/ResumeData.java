package com.in2it.irecruit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ResumeData {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "resume_generator")
	@SequenceGenerator(name="resume_generator", sequenceName = "resume_sequence")
	@Column(name = "resumeId")
	private long resumeId;

	@Column(name = "first_name")
	private String candidateFirstName;

	@Column(name = "last_name")
	private String candidateLastName;
	
	private String address;

	private String city;

	@OneToOne
	private State state;

	private String zip;

	private String resumeFileName;
	
	@JsonIgnore
	private String resumeFilePath;
	
	private String email;
	
	private String phone;
	
	private String domain;

	public ResumeData() {
		super();
	}

	public ResumeData(String candidateFirstName, String candidateLastName, String address, String city, State state,
			String zip, String resumeFileName, String resumeFilePath, String email, String phone, String domain) {
		super();
		this.candidateFirstName = candidateFirstName;
		this.candidateLastName = candidateLastName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.resumeFileName = resumeFileName;
		this.resumeFilePath = resumeFilePath;
		this.email = email;
		this.phone = phone;
		this.domain = domain;
	}

	public long getResumeId() {
		return resumeId;
	}

	public void setResumeId(long resumeId) {
		this.resumeId = resumeId;
	}

	public String getCandidateFirstName() {
		return candidateFirstName;
	}

	public void setCandidateFirstName(String candidateFirstName) {
		this.candidateFirstName = candidateFirstName;
	}

	public String getCandidateLastName() {
		return candidateLastName;
	}

	public void setCandidateLastName(String candidateLastName) {
		this.candidateLastName = candidateLastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getResumeFileName() {
		return resumeFileName;
	}

	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}

	public String getResumeFilePath() {
		return resumeFilePath;
	}

	public void setResumeFilePath(String resumeFilePath) {
		this.resumeFilePath = resumeFilePath;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "ResumeData [resumeId=" + resumeId + ", candidateFirstName=" + candidateFirstName
				+ ", candidateLastName=" + candidateLastName + ", address=" + address + ", city=" + city + ", state="
				+ state + ", zip=" + zip + ", resumeFileName=" + resumeFileName + ", resumeFilePath=" + resumeFilePath
				+ ", email=" + email + ", phone=" + phone + ", domain=" + domain + "]";
	}

}
