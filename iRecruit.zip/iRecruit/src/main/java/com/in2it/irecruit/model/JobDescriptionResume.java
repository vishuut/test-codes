package com.in2it.irecruit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(
		name="jd_resume_mapping",
		uniqueConstraints= @UniqueConstraint(columnNames={"job_description_id", "resume_data_resume_id"})
)
public class JobDescriptionResume {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@OneToOne
	@JsonProperty(access = Access.WRITE_ONLY)
	private JobDescription jobDescription;
	
	@OneToOne
	private ResumeData resumeData;
	
	@OneToOne
	@JsonIgnore
	private AppUser createdBy;

	public JobDescriptionResume() {
		super();
	}

	public JobDescriptionResume(JobDescription jobDescription, ResumeData resumeData, AppUser createdBy) {
		super();
		this.jobDescription = jobDescription;
		this.resumeData = resumeData;
		this.createdBy = createdBy;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@JsonIgnore
	public JobDescription getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(JobDescription jobDescription) {
		this.jobDescription = jobDescription;
	}

	public ResumeData getResumeData() {
		return resumeData;
	}

	public void setResumeData(ResumeData resumeData) {
		this.resumeData = resumeData;
	}

	public AppUser getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AppUser createdBy) {
		this.createdBy = createdBy;
	}
	
	

}
