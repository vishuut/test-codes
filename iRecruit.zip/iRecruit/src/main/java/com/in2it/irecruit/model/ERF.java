package com.in2it.irecruit.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.in2it.irecruit.repository.projector.AppUserProjector;

@Entity
@Table(name = "erf")
public class ERF {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "erf_generator")
	@SequenceGenerator(name="erf_generator", sequenceName = "erf_sequence")
	@Column(name = "erf_id")
	private long erfId;
	
	@Transient
	private String erfNumber;

	@OneToOne
	private Department department;

	@Column(name = "position", columnDefinition = "INT(3)")
	private int totalPosition;

	@Column(name = "requisition_category", columnDefinition = "VARCHAR(100) default ''")
	private String requisitionCategory;

	@OneToOne
	private Project project;

	@OneToOne
	private ResourceAllocation resourceAllocation;

	private long maxBudget;
	
	private String currency;

	@OneToMany(mappedBy = "erf", cascade = CascadeType.PERSIST)
	private List<ERFAddress> sourceAddresses;

	@OneToMany(mappedBy = "erf", cascade = CascadeType.PERSIST)
	private List<ERFAddress> workAddresses;
	
	@OneToOne
	private OfficeLocation workLocation;

	@OneToOne
	private OrganizationEntity entity;

	@Column(name = "generate_date")
	private LocalDate generateDate;

	@Column(name = "erf_status", columnDefinition = "VARCHAR(100) default ''")
	private String erfStatus;

	@Column(name = "remark", columnDefinition = "VARCHAR(100) default ''")
	private String remark;

	@OneToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private AppUser createdBy;
	
	@Transient
	private Map<String, String> erfOwner;
	
	public ERF() {
		super();
	}

	public long getErfId() {
		return erfId;
	}

	public void setErfId(long erfId) {
		this.erfId = erfId;
	}

	public String getErfNumber() {
		String number = String.format("%06d", this.erfId);
		String erfNumber = "PROJ-" + number;
		return erfNumber;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public int getTotalPosition() {
		return totalPosition;
	}

	public void setTotalPosition(int position) {
		this.totalPosition = position;
	}

	public String getRequisitionCategory() {
		return requisitionCategory;
	}

	public void setRequisitionCategory(String requisitionCategory) {
		this.requisitionCategory = requisitionCategory;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public ResourceAllocation getResourceAllocation() {
		return resourceAllocation;
	}

	public void setResourceAllocation(ResourceAllocation resourceAllocation) {
		this.resourceAllocation = resourceAllocation;
	}

	public long getMaxBudget() {
		return maxBudget;
	}

	public void setMaxBudget(long budget) {
		this.maxBudget = budget;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<ERFAddress> getSourceAddresses() {
		List<ERFAddress> sourceAddress = new ArrayList<ERFAddress>();
		for (ERFAddress erfAddress : this.sourceAddresses) {
			if(erfAddress.getAddressType().equals("source"))
				sourceAddress.add(erfAddress);
		}
		return sourceAddress;
	}

	public void setSourceAddresses(List<ERFAddress> sourceAddresses) {
		for (ERFAddress erfAddress : sourceAddresses) {
			erfAddress.setAddressType("source");
		}
		this.sourceAddresses = sourceAddresses;
	}

	public List<ERFAddress> getWorkAddresses() {
		List<ERFAddress> workAddress = new ArrayList<ERFAddress>();
		for (ERFAddress erfAddress : this.workAddresses) {
			if(erfAddress.getAddressType().equals("work"))
				workAddress.add(erfAddress);
		}
		return workAddress;
	}

	public void setWorkAddresses(List<ERFAddress> workAddresses) {
		for (ERFAddress erfAddress : workAddresses) {
			erfAddress.setAddressType("work");
		}
		this.workAddresses = workAddresses;
	}

	public OfficeLocation getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(OfficeLocation workLocation) {
		this.workLocation = workLocation;
	}

	public OrganizationEntity getEntity() {
		return entity;
	}

	public void setEntity(OrganizationEntity entity) {
		this.entity = entity;
	}

	public LocalDate getGenerateDate() {
		return generateDate;
	}

	public void setGenerateDate(LocalDate generateDate) {
		this.generateDate = generateDate;
	}

	public AppUser getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AppUser createdBy) {
		this.createdBy = createdBy;
	}

	public String getErfStatus() {
		return erfStatus;
	}

	public void setErfStatus(String erfStatus) {
		this.erfStatus = erfStatus;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Map<String, String> getErfOwner() {
		setErfOwner();
		return erfOwner;
	}
	
	public void setErfOwner() {
		erfOwner = new HashMap<String, String>();
		erfOwner.put("username", this.createdBy.getUsername());
		erfOwner.put("firstName", this.createdBy.getFirstName());
		erfOwner.put("lastName", this.createdBy.getLastName());
	}

}
