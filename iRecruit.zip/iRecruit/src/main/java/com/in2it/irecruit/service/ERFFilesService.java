package com.in2it.irecruit.service;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

public interface ERFFilesService {
	
	String saveFileFromMultipartFormData(MultipartFile file, String targetDirPath, String fileName);
	List<String> saveMultipleFilesFromMultipartFormData(MultipartFile[] files, String targetDirPath);
	Resource getFileAsResource(String filePath);
	
}
