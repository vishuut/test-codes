package com.in2it.irecruit.service;

import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.ERF;
import com.in2it.irecruit.model.TrackLead;

public interface TrackLeadService {

	List<TrackLead> saveTrackLead(List<TrackLead> trackLead) throws UnexpectedInternalError;

	TrackLead findByErfAndUser(ERF erf, AppUser createdBy);

	List<TrackLead> getTrackleadsForErf(long erfId);

}
