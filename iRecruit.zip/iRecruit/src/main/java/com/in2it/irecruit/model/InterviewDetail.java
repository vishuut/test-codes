
package com.in2it.irecruit.model;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.in2it.irecruit.constant.InterviewStatus;
import com.in2it.irecruit.constant.InterviewType;

@Entity
@Table(
		uniqueConstraints= @UniqueConstraint(columnNames={"job_description_resume_id", "round"})
)
public class InterviewDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@OneToOne
	@JsonProperty(access = Access.WRITE_ONLY)
	private JobDescriptionResume jobDescriptionResume;

	@Enumerated(EnumType.STRING)
	private InterviewType interviewType;

	private int round;

	@OneToMany(cascade = CascadeType.PERSIST)
	private List<InternalPanel> internalPanel;

	@OneToMany(cascade = CascadeType.PERSIST)
	private List<ExternalPanel> externalPanel;

	private LocalDateTime interviewDateTime;

	@Enumerated(EnumType.STRING)
	private InterviewStatus status;

	public InterviewDetail() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public JobDescriptionResume getJobDescriptionResume() {
		return this.jobDescriptionResume;
	}

	public void setJobDescriptionResume(JobDescriptionResume jobDescriptionResume) {
		this.jobDescriptionResume = jobDescriptionResume;
	}

	public InterviewType getInterviewType() {
		return this.interviewType;
	}

	public void setInterviewType(InterviewType interviewType) {
		this.interviewType = interviewType;
	}

	public int getRound() {
		return this.round;
	}

	public void setRound(int round) {
		this.round = round;
	}

	public List<InternalPanel> getInternalPanel() {
		return this.internalPanel;
	}

	public void setInternalPanel(List<InternalPanel> internalPanel) {
		this.internalPanel = internalPanel;
	}

	public List<ExternalPanel> getExternalPanel() {
		return this.externalPanel;
	}

	public void setExternalPanel(List<ExternalPanel> externalPanel) {
		this.externalPanel = externalPanel;
	}

	public LocalDateTime getInterviewDateTime() {
		return this.interviewDateTime;
	}

	public void setInterviewDateTime(LocalDateTime interviewDateTime) {
		this.interviewDateTime = interviewDateTime;
	}

	public InterviewStatus getStatus() {
		return status;
	}

	public void setStatus(InterviewStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "InterviewDetail [id=" + id + ", jobDescriptionResume=" + jobDescriptionResume + ", interviewType="
				+ interviewType + ", round=" + round + ", internalPanel=" + internalPanel + ", externalPanel="
				+ externalPanel + ", interviewDateTime=" + interviewDateTime + ", status=" + status + "]";
	}

}