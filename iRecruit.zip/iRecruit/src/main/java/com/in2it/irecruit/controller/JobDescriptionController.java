package com.in2it.irecruit.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.JobDescription;
import com.in2it.irecruit.model.JobDescriptionRecruiter;
import com.in2it.irecruit.model.JobDescriptionResume;
import com.in2it.irecruit.repository.projector.AppUserProjector;
import com.in2it.irecruit.service.JobDescriptionService;
import com.in2it.irecruit.wrapper.JobDescriptionListingWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionRecruiterWrapper;
import com.in2it.irecruit.wrapper.JobDescriptionResumeWrapper;

@RestController
@RequestMapping(value = "/irecruit-api/jd")
public class JobDescriptionController {

	@Autowired
	private JobDescriptionService jobDescriptionService;

	@PostMapping(value = "/add-jd")
	public ResponseEntity<List<JobDescription>> addNewJobDescription(@RequestBody List<JobDescription> jobDescriptions,Principal userPrincipal) throws UnexpectedInternalError {
		return new ResponseEntity<>(jobDescriptionService.addJobDescription(jobDescriptions, userPrincipal), HttpStatus.OK);
	}
	
	@GetMapping(value = "/get-jd")
	public ResponseEntity<List<JobDescriptionListingWrapper>> getJobDescription(){
		return new ResponseEntity<List<JobDescriptionListingWrapper>>(jobDescriptionService.getJobDescription(),HttpStatus.OK);
	}
	
	@PostMapping(value = "/attach-resume")
	public ResponseEntity<JobDescriptionResumeWrapper> attachResumeToJD(@RequestBody JobDescriptionResumeWrapper jobDescriptionResumeDta, Principal userPrincipal) throws UnexpectedInternalError {
		return new ResponseEntity<JobDescriptionResumeWrapper>(jobDescriptionService.addResumeToJD(jobDescriptionResumeDta, userPrincipal), HttpStatus.OK);
	}
	
	@PostMapping(value = "/assign-recruiter")
	public ResponseEntity<JobDescriptionRecruiterWrapper> attachRecruiterToJD(@RequestBody JobDescriptionRecruiterWrapper jobDescriptionRecruiterDta, Principal userPrincipal) throws UnexpectedInternalError {
		return new ResponseEntity<JobDescriptionRecruiterWrapper>(jobDescriptionService.attachRecruiterToJD(jobDescriptionRecruiterDta, userPrincipal), HttpStatus.OK);
	}
	
	@GetMapping(value = "/get-recruiters")
	public ResponseEntity<List<AppUserProjector>> getAllRecruiters() {
		return ResponseEntity.ok(jobDescriptionService.getAllRecruiters());
	}

	@GetMapping(value = "/get-attached-resumes/{jdId}")
	public ResponseEntity<List<JobDescriptionResume>> getAttachedResume(@PathVariable(name = "jdId") long jdId){
		return ResponseEntity.ok(jobDescriptionService.getAttachedResumes(jdId));
	}

	@GetMapping(value = "/get-assigned-recruiters/{jdId}")
	public ResponseEntity<List<JobDescriptionRecruiter>> getAssignedRecruiters(@PathVariable(name = "jdId") long jdId){
		return ResponseEntity.ok(jobDescriptionService.getAssignedRecruiters(jdId));
	}
	
}
