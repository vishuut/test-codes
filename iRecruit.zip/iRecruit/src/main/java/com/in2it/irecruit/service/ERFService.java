package com.in2it.irecruit.service;

import java.security.Principal;
import java.util.List;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.ERF;

public interface ERFService {

	ERF saveERF(ERF erf , Principal userPrincipal);

	List<ERF> viewERF(Principal userPrincipal) throws UnexpectedInternalError;

	ERF viewERFById(long erfId) throws UnexpectedInternalError;
}
