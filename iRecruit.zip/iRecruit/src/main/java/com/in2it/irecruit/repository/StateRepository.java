package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.State;

@Repository
public interface StateRepository extends JpaRepository<State, Long> {
	
	List<State> findByCountry(Country country);

}
