package com.in2it.irecruit.service.Impl;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.service.PermissionService;
import com.in2it.irecruit.service.UserService;
import com.in2it.irecruit.service.abstractimpl.PermissionAbstractService;

@Service
public class PermissionServiceImpl extends PermissionAbstractService implements PermissionService {
	
	@Autowired
	UserService userService;
		
	@Override
	public Map<String, List<String>> getCategoryWisePermission() throws UnexpectedInternalError {
		Map<String, List<String>> permissions = new HashMap<>();
		
		permissions.put(PermissionCategory.ERF.toString(), getApplicablePermissionsByCategory(PermissionCategory.ERF.toString()));
		permissions.put(PermissionCategory.FEEDBACK.toString(), getApplicablePermissionsByCategory(PermissionCategory.FEEDBACK.toString()));
		permissions.put(PermissionCategory.OFFER.toString(), getApplicablePermissionsByCategory(PermissionCategory.OFFER.toString()));
		permissions.put(PermissionCategory.INTERVIEW.toString(), getApplicablePermissionsByCategory(PermissionCategory.INTERVIEW.toString()));
		permissions.put(PermissionCategory.PANEL.toString(), getApplicablePermissionsByCategory(PermissionCategory.PANEL.toString()));
		permissions.put(PermissionCategory.RECRUITER.toString(), getApplicablePermissionsByCategory(PermissionCategory.RECRUITER.toString()));
		permissions.put(PermissionCategory.RESUME.toString(), getApplicablePermissionsByCategory(PermissionCategory.RESUME.toString()));
		permissions.put(PermissionCategory.ROLE.toString(), getApplicablePermissionsByCategory(PermissionCategory.ROLE.toString()));
		
		return permissions;
	}
	
	@Override
	public Map<String, Boolean> assignPermissionToUser(Principal userPrincipal, String permitedAction, String permitOn) throws UnexpectedInternalError {
		Map<String, Boolean> assignmentStatus = new HashMap<String, Boolean>();
		
		AppUser user = userService.getUserByEmail(userPrincipal.getName());
		
		assignmentStatus.put("status", allocatePermissionToUser(user, permitOn, permitedAction));
		
		return assignmentStatus;
	}

	@Override
	public Map<String, Boolean> revokePermissionFromUser(Principal userPrincipal, String permitedAction,
			String permitOn) throws UnexpectedInternalError {
		Map<String, Boolean> revokeStatus = new HashMap<String, Boolean>();
		
		AppUser user = userService.getUserByEmail(userPrincipal.getName());
		
		revokeStatus.put("status",  unallocatePermissionFromUser(user, permitOn, permitedAction));
		
		return revokeStatus;
	}
}
