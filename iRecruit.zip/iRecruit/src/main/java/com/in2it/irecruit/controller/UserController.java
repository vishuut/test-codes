package com.in2it.irecruit.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in2it.irecruit.repository.projector.AppUserProjector;
import com.in2it.irecruit.service.UserService;

@RestController
@RequestMapping("/irecruit-api/user")
public class UserController {

	@Autowired
	private UserService userService;

	// @PreAuthorize("hasAuthority('ERF_VIEW') or hasAuthority('ERF_OFFER')")
	@GetMapping(value = "/get-user-permissons")
	public ResponseEntity<Map<String, Object>> getUserPermission(Principal userPrincipal) {
		return new ResponseEntity<>(userService.getUserDetailsWithPermissions(userPrincipal.getName()), HttpStatus.OK);
	}
	
	@GetMapping(value = "/search-by-sapId/{sapId}")
	public ResponseEntity<List<AppUserProjector>> searchUsersBySapId(@PathVariable(name = "sapId") String sapId) {
		return new ResponseEntity<>(userService.searchBySapId(sapId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/search-by-username/{userName}")
	public ResponseEntity<List<AppUserProjector>> searchUsersByUserName(@PathVariable(name = "userName") String userName) {
		return new ResponseEntity<>(userService.searchByUserName(userName), HttpStatus.OK);
	}

}
