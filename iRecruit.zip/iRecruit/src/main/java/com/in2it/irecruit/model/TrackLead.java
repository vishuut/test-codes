package com.in2it.irecruit.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.in2it.irecruit.util.StringUtil;

@Entity
@Table(
		name="track_lead",
		uniqueConstraints= @UniqueConstraint(columnNames={"user_id", "erf_id"})
)
public class TrackLead {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@OneToOne
	@JoinColumn(name = "user_id")
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private AppUser user;
	
	@JsonIgnore
	private String domains;
	
	@Transient
	private List<String> domainsArray;
	
	private long budget;
	
	private int position;
	
	@OneToOne
	@JoinColumn(name = "erf_id")
	@JsonProperty(access = Access.WRITE_ONLY)
	private ERF erf;
	
	private LocalDate assignDate;

	public TrackLead() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public AppUser getUser() {
		return user;
	}

	public void setUser(AppUser user) {
		this.user = user;
	}

	public String getDomains() {
		return domains;
	}

	public void setDomains(String domains) {
		this.domains = domains;
		this.domainsArray = StringUtil.toListOfString(domains, ",");
	}

	public List<String> getDomainsArray() {
		if(domainsArray == null) {
			this.domainsArray = StringUtil.toListOfString(domains, ",");
		}
		return domainsArray;
	}

	public void setDomainsArray(List<String> domainsArray) {
		this.domainsArray = domainsArray;
		this.domains = StringUtil.toCommaSaperatedString(domainsArray);
	}

	public long getBudget() {
		return budget;
	}

	public void setBudget(long budget) {
		this.budget = budget;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public ERF getErf() {
		return erf;
	}

	public void setErf(ERF erf) {
		this.erf = erf;
	}

	public LocalDate getAssignDate() {
		return assignDate;
	}

	public void setAssignDate(LocalDate assignDate) {
		this.assignDate = assignDate;
	}
	
	
}
