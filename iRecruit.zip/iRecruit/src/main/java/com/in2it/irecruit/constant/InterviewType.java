package com.in2it.irecruit.constant;

public enum InterviewType {
    ONLINE(0, "Online"),
	MACHINE_TEST(1, "Machine Test"),
	F2F(2, "Face to Face"),
	DISCUSSION(3, "Discussion"),
	DECISION(4, "Decision"),
	EXT_F2F(5, "External - Face to Face"),
    EXT_REMOTE(6, "External - Remote");
    
    private final int value;
	private final String type;
	
	private InterviewType(int value, String type) {
		this.value = value;
		this.type = type;
	}
	
	public int value() {
		return this.value;
	}
	
	public String type() {
		return this.type;
	}
	
	@Override
	public String toString() {
		return "DataFilterType [value = "+ value +", type= "+ type +"]";
	}
}