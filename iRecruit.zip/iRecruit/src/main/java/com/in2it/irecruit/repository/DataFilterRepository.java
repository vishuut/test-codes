package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.model.DataFilter;

@Repository
public interface DataFilterRepository extends JpaRepository<DataFilter, Long>{
	
	public List<DataFilter> findByUserAndActive(AppUser user, boolean active);

}
