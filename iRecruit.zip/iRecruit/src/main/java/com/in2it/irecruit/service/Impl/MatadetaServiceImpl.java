package com.in2it.irecruit.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.OfficeLocation;
import com.in2it.irecruit.model.State;
import com.in2it.irecruit.repository.CountryRepository;
import com.in2it.irecruit.repository.DepartmentRepository;
import com.in2it.irecruit.repository.OfficeLocationRepository;
import com.in2it.irecruit.repository.OrganizationEntityRepository;
import com.in2it.irecruit.repository.ResourceAllocationRepository;
import com.in2it.irecruit.repository.StateRepository;
import com.in2it.irecruit.service.MetadataService;
import com.in2it.irecruit.service.ProjectService;

@Service
public class MatadetaServiceImpl implements MetadataService {

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private StateRepository stateRepo;

	@Autowired
	private OfficeLocationRepository officeLocationRepo;
	
	@Autowired
	private DepartmentRepository departmentRepo;
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private ResourceAllocationRepository resourceAllocationRepo;
	
	@Autowired
	private OrganizationEntityRepository orgEntityRepo;

	@Override
	public Country getCountryByNiceName(String nicename) throws UnexpectedInternalError {
		Optional<Country> country = countryRepo.findByNiceName(nicename.trim());
		country.orElseThrow(() -> new UnexpectedInternalError("Cannot find Country with nicename: " + nicename));
		return country.get();
	}

	@Override
	public List<Map<String, Object>> getAllCountries() {
		List<Map<String, Object>> listOfCountryName = new ArrayList<>();

		List<Country> countryObj = countryRepo.findAll();
		for (Country country : countryObj) {
			Map<String, Object> map = new HashMap<>();
			map.put("countryId", country.getCountryId());
			map.put("name", country.getNiceName());
			map.put("phonecode", country.getPhonecode());
			listOfCountryName.add(map);
		}
		return listOfCountryName;
	}

	@Override
	public Country findCountryById(long countryId) throws UnexpectedInternalError {
		Optional<Country> countryOpt = countryRepo.findById(countryId);
		countryOpt.orElseThrow(() -> new UnexpectedInternalError("Country not found with ID: " + countryId));
		return countryOpt.get();
	}

	@Override
	public List<State> getStatesByCountry(long countryId) throws UnexpectedInternalError {
		Country country = this.findCountryById(countryId);
		List<State> states = stateRepo.findByCountry(country);
		return states;
	}

	@Override
	public State getStateById(long stateId) throws UnexpectedInternalError {
		Optional<State> stateOpt = stateRepo.findById(stateId);
		stateOpt.orElseThrow(() -> new UnexpectedInternalError("Cannot find state with ID: " + stateId));
		return stateOpt.get();
	}

	@Override
	public List<OfficeLocation> getAllOfficeLocations() {
		return officeLocationRepo.findAll();
	}

	@Override
	public List<OfficeLocation> getOfficeLocationsByCountry(long countryId) throws UnexpectedInternalError {
		Country country = this.findCountryById(countryId);
		List<OfficeLocation> locations = officeLocationRepo.findByCountry(country);
		return locations;
	}

	@Override
	public OfficeLocation getOfficeLocationById(long locationId) throws UnexpectedInternalError {
		Optional<OfficeLocation> locationOpt = officeLocationRepo.findById(locationId);
		locationOpt
				.orElseThrow(() -> new UnexpectedInternalError("Cannot find Office Location with ID: " + locationId));
		return locationOpt.get();
	}
	
	@Override
	public Map<String, Object> getERFGenerationMetadata() {
		Map<String, Object> metadata = new HashMap<String, Object>();
		metadata.put("departments", departmentRepo.findAll());
		metadata.put("projects", projectService.getAllProjects());
		metadata.put("resourceAllocations", resourceAllocationRepo.findAll());
		metadata.put("countries", getAllCountries());
		metadata.put("officeLocations", getAllOfficeLocations());
		metadata.put("entities", orgEntityRepo.findAll());
		return metadata;
	}
}
