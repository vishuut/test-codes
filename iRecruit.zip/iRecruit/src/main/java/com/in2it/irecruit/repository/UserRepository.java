package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.in2it.irecruit.model.AppUser;
import com.in2it.irecruit.repository.projector.AppUserProjector;


@Repository
public interface UserRepository extends JpaRepository<AppUser, Long> {

	AppUser findByEmail(String email);
	
	List<AppUserProjector> readBySapIdStartsWith(String sapId);
	List<AppUserProjector> readByUsernameContainingIgnoreCase(String username);
	List<AppUserProjector> readByRecruiter(boolean recruiter);
	
	AppUserProjector readById(long id);
	AppUser findBySapId(String sapId);

}
