package com.in2it.irecruit.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Project;
import com.in2it.irecruit.repository.ProjectRepository;
import com.in2it.irecruit.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepo;

	@Override
	public List<Project> getAllProjects() {
		return projectRepo.findAll();
	}

	@Override
	public Project addProject(String projectName) {
		Project newProject = new Project();
		newProject.setProjectName(projectName);
		projectRepo.save(newProject);
		return newProject;
	}

	@Override
	public Project getProjectById(long projectId) throws UnexpectedInternalError {
		Optional<Project> projectOpt = projectRepo.findById(projectId);
		projectOpt.orElseThrow(() -> new UnexpectedInternalError("Project not found with ID: " + projectId));
		return projectOpt.get();
	}

}
