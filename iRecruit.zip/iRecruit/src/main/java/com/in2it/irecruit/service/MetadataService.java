package com.in2it.irecruit.service;

import java.util.List;
import java.util.Map;

import com.in2it.irecruit.exception.UnexpectedInternalError;
import com.in2it.irecruit.model.Country;
import com.in2it.irecruit.model.OfficeLocation;
import com.in2it.irecruit.model.State;


public interface MetadataService {
	
	Country getCountryByNiceName(String nicename) throws UnexpectedInternalError;

	List<Map<String , Object>> getAllCountries();

	Country findCountryById(long filterValueId) throws UnexpectedInternalError;
	
	List<State> getStatesByCountry(long countryId) throws UnexpectedInternalError;
	
	State getStateById(long stateId) throws UnexpectedInternalError;

	List<OfficeLocation> getAllOfficeLocations();

	List<OfficeLocation> getOfficeLocationsByCountry(long countryId) throws UnexpectedInternalError;

	OfficeLocation getOfficeLocationById(long locationId) throws UnexpectedInternalError;

	Map<String, Object> getERFGenerationMetadata();

}
