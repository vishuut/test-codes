package com.in2it.irecruit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.in2it.irecruit.model.JobDescription;
import com.in2it.irecruit.model.JobDescriptionRecruiter;

@Repository
public interface JobDescriptionRecruiterRepository extends JpaRepository<JobDescriptionRecruiter, Long> {
	@Transactional
	List<JobDescriptionRecruiter> removeByJobDescription(JobDescription jobDescription);

	List<JobDescriptionRecruiter> findByJobDescription(JobDescription jd);
}
