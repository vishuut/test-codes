package com.in2it.irecruit.constant;

public enum DataFilterType {
	
	// Do not change the ordering of these definitions. It will directly effect the data fetched from the tables
	NO_FILTER(0, "No Filter"),
	TYPE_1(1, "Country"),
	TYPE_2(2, "Department"),
	TYPE_3(3, "Current Location"),
	TYPE_4(4, "Entity"),
	TYPE_5(5, "Project"),
	TYPE_6(6, "Resource Allocation");
	
	private final int value;
	private final String filterOn;
	
	private DataFilterType(int value, String filterOn) {
		this.value = value;
		this.filterOn = filterOn;
	}
	
	public int value() {
		return this.value;
	}
	
	public String filterOn() {
		return this.filterOn;
	}
	
	@Override
	public String toString() {
		return "DataFilterType [value = "+ value +", filterOn= "+ filterOn +"]";
	}

}
