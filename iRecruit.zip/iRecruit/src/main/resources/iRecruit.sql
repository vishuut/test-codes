
INSERT INTO salon_app.permission (permission_id, category, auth_key, TYPE)
VALUES
	(1,'ERF','ERF_VIEW','VIEW'),
	(2,'ERF','ERF_UPDATE','UPDATE'),
	(3,'ERF','ERF_APPROVE','APPROVE'),
	(4,'ERF','ERF_GENERATE','GENERATE'),
	(5,'ERF','ERF_CLOSE','CLOSE'),
	(6,'ERF','ERF_DELETE','DELETE'),
	(7,'OFFER','OFFER_GENERATE','GENERATE'),
	(8,'OFFER','OFFER_VIEW','VIEW'),
	(9,'OFFER','OFFER_UPDATE','UPDATE'),
	(10,'OFFER','OFFER_APPROVE','APPROVE'),
	(11,'INTERVIEW','INTERVIEW_SCHEDULE','SCHEDULE'),
	(12,'INTERVIEW','INTERVIEW_UPDATE','UPDATE'),
	(13,'INTERVIEW','INTERVIEW_VIEW','VIEW'),
	(14,'RESUME','RESUME_UPLOAD','UPLOAD'),
	(15,'RESUME','RESUME_DOWNLOAD','DOWNLOAD'),
	(16,'RESUME','RESUME_VIEW','VIEW'),
	(17,'RESUME','RESUME_SHORTLIST','SHORTLIST'),
	(18,'RECRUITER','RECRUITER_ASSIGN','ASSIGN'),
	(19,'RECRUITER','RECRUITER_UPDATE','UPDATE'),
	(20,'RECRUITER','RECRUITER_VIEW','VIEW'),
	(21,'ROLE','ROLE_ASSIGN','ASSIGN'),
	(22,'PANEL','PANEL_ASSIGN','ASSIGN'),
	(23,'PANEL','PANEL_UPDATE','UPDATE'),
	(24,'PANEL','PANEL_VIEW','VIEW'),
	(25,'FEEDBACK','FEEDBACK_UPDATE','UPDATE'),
	(26,'FEEDBACK','FEEDBACK_VIEW','VIEW'),
	(27,'FEEDBACK','FEEDBACK_APPROVE','APPROVE');

INSERT INTO irecruit.role(role_id,role_name) 
VALUES
	(1,'BUHEAD'),
	(2,'ADMIN'),
	(3,'INITIATOR'),
	(4,'RECRUITER'),
	(5,'PANEL');

INSERT INTO irecruit.role_permission(role_id,permission_id) 
VALUES
	(3, 1),
	(3, 4),
	(3, 5),
	(4, 18),
	(4, 19),
	(4, 20),
	(5, 22),
	(5, 23),
	(5, 24);

INSERT INTO irecruit.assigned_permission(assigned_permission_id, assigned, user_id, app_permission_permission_id)
VALUES
	(1, 1, 1, 1),
	(2, 1, 1, 2),
	(3, 1, 1, 3),
	(4, 1, 1, 4);
	
	
	
	
	
INSERT INTO irecruit.project (project_name) SELECT DISTINCT u.project AS 'project_name' FROM user u WHERE u.project IS NOT NULL AND u.project!=''; 

UPDATE user u1  left JOIN user u2 ON u1.manager_id =u2.sap_id   
SET u1.manager_name =concat (u2.first_name, ' ', u2.last_name)


UPDATE user u1  left JOIN user u2 ON u1.matrix_manager_id =u2.sap_id   
SET u1.matrix_manager_name =concat (u2.first_name, ' ', u2.last_name)


INSERT INTO irecruit.state(state_name, country_country_id)
VALUES
	('Andhra Pradesh', 1),
	('Arunachal Pradesh', 1),
	('Assam', 1),
	('Bihar', 1),
	('Chhattisgarh', 1),
	('Goa', 1),
	('Gujarat', 1),
	('Haryana', 1),
	('Himachal Pradesh', 1),
	('Jharkhand', 1);
	
	
	CREATE TABLE `oauth_access_token` (
	`token_id` VARCHAR(256) NULL DEFAULT NULL,
	`token` BLOB NULL,
	`authentication_id` VARCHAR(256) NOT NULL,
	`user_name` VARCHAR(256) NULL DEFAULT NULL,
	`client_id` VARCHAR(256) NULL DEFAULT NULL,
	`authentication` BLOB NULL,
	`refresh_token` VARCHAR(256) NULL DEFAULT NULL,
	PRIMARY KEY (`authentication_id`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
;

CREATE TABLE `oauth_refresh_token` (
	`token_id` VARCHAR(256) NULL DEFAULT NULL,
	`token` BLOB NULL,
	`authentication` BLOB NULL
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
;


